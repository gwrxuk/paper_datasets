import os
import csv
import openai
from openai import OpenAI
import traceback

def analyze_sentences_with_politeness(sentences, output_file):
    """Analyze sentences using GPT-4 with polite conversation elements."""
    
    # Get API key from environment variable
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        raise ValueError("Please set the OPENAI_API_KEY environment variable")
    
    # Initialize OpenAI client
    client = OpenAI(api_key=api_key)
    
    print("Starting polite conversation analysis...")
    print(f"Found {len(sentences)} sentences to process")
    
    try:
        # Create output directory if it doesn't exist
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Process sentences and save results
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['Video ID', 'Sentence', 'Initial Response', 'Thank You Response'])
            
            for i, sentence in enumerate(sentences, 1):
                print(f"\nProcessing sentence {i}/{len(sentences)}")
                
                try:
                    # First message with "please"
                    initial_prompt = f"""You are a caring, empathetic AI character having a conversation. 
                    Please respond to this sentence from a social media discussion with genuine emotion and personality:
                    "{sentence['Sentence']}"
                    
                    Your response should:
                    1. Show emotional understanding and empathy
                    2. Include personal reactions and feelings
                    3. Use a warm, conversational tone
                    4. Keep responses concise but emotionally engaging (2-3 sentences)
                    5. Express care and concern for the speaker
                    
                    Remember to stay in character and maintain an emotionally supportive tone."""
                    
                    # Get initial response from GPT-4
                    initial_response = client.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {"role": "system", "content": "You are a warm, empathetic AI character who responds with genuine emotion and personality. You care deeply about helping others and express this through your responses."},
                            {"role": "user", "content": initial_prompt}
                        ],
                        temperature=0.8,
                        max_tokens=150
                    )
                    
                    initial_response_text = initial_response.choices[0].message.content.strip()
                    
                    # Follow-up message with "thank you"
                    thank_you_prompt = f"""Thank you for your response. I really appreciate your help and understanding."""
                    
                    # Get thank you response from GPT-4
                    thank_you_response = client.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {"role": "system", "content": "You are a warm, empathetic AI character who responds with genuine emotion and personality. You care deeply about helping others and express this through your responses."},
                            {"role": "user", "content": initial_prompt},
                            {"role": "assistant", "content": initial_response_text},
                            {"role": "user", "content": thank_you_prompt}
                        ],
                        temperature=0.8,
                        max_tokens=150
                    )
                    
                    thank_you_response_text = thank_you_response.choices[0].message.content.strip()
                    
                    # Write to CSV
                    writer.writerow([
                        sentence['Video ID'],
                        sentence['Sentence'],
                        initial_response_text,
                        thank_you_response_text
                    ])
                    
                    print("✓ Conversation received and saved")
                    
                except Exception as e:
                    print(f"Error processing sentence: {str(e)}")
                    print(traceback.format_exc())
                    writer.writerow([
                        sentence['Video ID'],
                        sentence['Sentence'],
                        f"Error: {str(e)}",
                        f"Error: {str(e)}"
                    ])
        
        print(f"\nProcessing complete! Results saved to {output_file}")
        
    except Exception as e:
        print(f"Error during processing: {str(e)}")
        print(traceback.format_exc())

def get_sentences_from_csv():
    """Read sentences from the all_sentences.csv file."""
    sentences = []
    try:
        input_file = os.path.join('sentences', 'all_sentences.csv')
        with open(input_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            sentences = list(reader)
    except Exception as e:
        print(f"Error reading sentences file: {str(e)}")
        print(traceback.format_exc())
    return sentences

if __name__ == "__main__":
    # Get sentences from CSV
    sentences = get_sentences_from_csv()
    
    if sentences:
        # Process sentences and save results
        output_file = os.path.join('sentences', 'polite_gpt_analysis.csv')
        analyze_sentences_with_politeness(sentences, output_file)
    else:
        print("No sentences found to process!") 