import pandas as pd
import numpy as np
from textblob import TextBlob
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import os

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Create output directory if it doesn't exist
os.makedirs('_polite_analysis', exist_ok=True)

# Load the data
gpt_data = pd.read_csv('polite_gpt_analysis.csv')
gemini_data = pd.read_csv('polite_gemini_analysis.csv')

# 1. Sentiment Analysis
def perform_sentiment_analysis(text):
    return TextBlob(text).sentiment.polarity

# Analyze both initial and thank you responses
for response_type in ['Initial Response', 'Thank You Response']:
    gpt_data[f'{response_type}_sentiment'] = gpt_data[response_type].apply(perform_sentiment_analysis)
    gemini_data[f'{response_type}_sentiment'] = gemini_data[response_type].apply(perform_sentiment_analysis)

    # Plot sentiment distributions
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    sns.histplot(gpt_data[f'{response_type}_sentiment'], bins=30)
    plt.title(f'GPT {response_type} Sentiment Distribution')
    plt.subplot(1, 2, 2)
    sns.histplot(gemini_data[f'{response_type}_sentiment'], bins=30)
    plt.title(f'Gemini {response_type} Sentiment Distribution')
    plt.tight_layout()
    plt.savefig(f'_polite_analysis/{response_type.lower().replace(" ", "_")}_sentiment_distribution.png')
    plt.close()

# 2. Topic Modeling
def perform_topic_modeling(texts, n_topics=5):
    vectorizer = CountVectorizer(max_df=0.95, min_df=2, stop_words='english')
    doc_term_matrix = vectorizer.fit_transform(texts)
    
    lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda.fit(doc_term_matrix)
    
    feature_names = vectorizer.get_feature_names_out()
    return lda, feature_names

# Perform topic modeling for both models and response types
for response_type in ['Initial Response', 'Thank You Response']:
    gpt_lda, gpt_features = perform_topic_modeling(gpt_data[response_type])
    gemini_lda, gemini_features = perform_topic_modeling(gemini_data[response_type])

    # Save topic modeling results
    def save_topics(model, feature_names, filename):
        topics = []
        for topic_idx, topic in enumerate(model.components_):
            top_words = [feature_names[i] for i in topic.argsort()[:-10:-1]]
            topics.append(f"Topic {topic_idx + 1}: {', '.join(top_words)}")
        
        with open(f'_polite_analysis/{filename}', 'w') as f:
            f.write('\n'.join(topics))

    save_topics(gpt_lda, gpt_features, f'gpt_{response_type.lower().replace(" ", "_")}_topics.txt')
    save_topics(gemini_lda, gemini_features, f'gemini_{response_type.lower().replace(" ", "_")}_topics.txt')

# 3. Word Usage Analysis
def analyze_word_usage(texts, title, filename):
    words = ' '.join(texts).lower()
    tokens = word_tokenize(words)
    stop_words = set(stopwords.words('english'))
    words = [word for word in tokens if word.isalnum() and word not in stop_words]
    
    word_freq = Counter(words).most_common(20)
    words, freqs = zip(*word_freq)
    
    plt.figure(figsize=(12, 6))
    plt.bar(words, freqs)
    plt.xticks(rotation=45, ha='right')
    plt.title(f'Top 20 Words - {title}')
    plt.tight_layout()
    plt.savefig(f'_polite_analysis/{filename}')
    plt.close()

for response_type in ['Initial Response', 'Thank You Response']:
    analyze_word_usage(gpt_data[response_type], f'GPT {response_type}', f'gpt_{response_type.lower().replace(" ", "_")}_word_usage.png')
    analyze_word_usage(gemini_data[response_type], f'Gemini {response_type}', f'gemini_{response_type.lower().replace(" ", "_")}_word_usage.png')

# 4. Paired t-test
# Calculate response lengths
for response_type in ['Initial Response', 'Thank You Response']:
    gpt_data[f'{response_type}_length'] = gpt_data[response_type].str.len()
    gemini_data[f'{response_type}_length'] = gemini_data[response_type].str.len()

    # Perform paired t-test
    t_stat, p_value = stats.ttest_rel(gpt_data[f'{response_type}_length'], gemini_data[f'{response_type}_length'])

    # Save t-test results
    with open(f'_polite_analysis/{response_type.lower().replace(" ", "_")}_paired_t_test_results.txt', 'w') as f:
        f.write(f'T-statistic: {t_stat}\n')
        f.write(f'P-value: {p_value}\n')
        f.write(f'Significant difference: {"Yes" if p_value < 0.05 else "No"}')

# 5. Distribution Analysis
for response_type in ['Initial Response', 'Thank You Response']:
    # Response length distribution
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    sns.histplot(gpt_data[f'{response_type}_length'], bins=30)
    plt.title(f'GPT {response_type} Length Distribution')
    plt.subplot(1, 2, 2)
    sns.histplot(gemini_data[f'{response_type}_length'], bins=30)
    plt.title(f'Gemini {response_type} Length Distribution')
    plt.tight_layout()
    plt.savefig(f'_polite_analysis/{response_type.lower().replace(" ", "_")}_length_distribution.png')
    plt.close()

# Save summary statistics
summary_stats = pd.DataFrame({
    'GPT': {
        'Initial Response Mean Length': gpt_data['Initial Response_length'].mean(),
        'Initial Response Std Length': gpt_data['Initial Response_length'].std(),
        'Initial Response Mean Sentiment': gpt_data['Initial Response_sentiment'].mean(),
        'Initial Response Std Sentiment': gpt_data['Initial Response_sentiment'].std(),
        'Thank You Response Mean Length': gpt_data['Thank You Response_length'].mean(),
        'Thank You Response Std Length': gpt_data['Thank You Response_length'].std(),
        'Thank You Response Mean Sentiment': gpt_data['Thank You Response_sentiment'].mean(),
        'Thank You Response Std Sentiment': gpt_data['Thank You Response_sentiment'].std()
    },
    'Gemini': {
        'Initial Response Mean Length': gemini_data['Initial Response_length'].mean(),
        'Initial Response Std Length': gemini_data['Initial Response_length'].std(),
        'Initial Response Mean Sentiment': gemini_data['Initial Response_sentiment'].mean(),
        'Initial Response Std Sentiment': gemini_data['Initial Response_sentiment'].std(),
        'Thank You Response Mean Length': gemini_data['Thank You Response_length'].mean(),
        'Thank You Response Std Length': gemini_data['Thank You Response_length'].std(),
        'Thank You Response Mean Sentiment': gemini_data['Thank You Response_sentiment'].mean(),
        'Thank You Response Std Sentiment': gemini_data['Thank You Response_sentiment'].std()
    }
})

summary_stats.to_csv('_polite_analysis/summary_statistics.csv')

print("Analysis complete! Results saved in _polite_analysis folder.") 