import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import os

# Create output directory if it doesn't exist
os.makedirs('_polite_analysis/figures', exist_ok=True)

# Load the data
gpt_data = pd.read_csv('polite_gpt_analysis.csv')
gemini_data = pd.read_csv('polite_gemini_analysis.csv')

# Calculate response lengths
for response_type in ['Initial Response', 'Thank You Response']:
    gpt_data[f'{response_type}_length'] = gpt_data[response_type].str.len()
    gemini_data[f'{response_type}_length'] = gemini_data[response_type].str.len()

# 1. Response Length Distribution Comparison
plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
data = pd.DataFrame({
    'GPT': gpt_data['Initial Response_length'],
    'Gemini': gemini_data['Initial Response_length']
})
sns.boxplot(data=data)
plt.title('Initial Response Length Distribution')
plt.ylabel('Character Count')

plt.subplot(1, 2, 2)
data = pd.DataFrame({
    'GPT': gpt_data['Thank You Response_length'],
    'Gemini': gemini_data['Thank You Response_length']
})
sns.boxplot(data=data)
plt.title('Thank You Response Length Distribution')
plt.ylabel('Character Count')
plt.tight_layout()
plt.savefig('_polite_analysis/figures/response_length_distribution.png')
plt.close()

# 2. Sentiment Analysis Visualization
from textblob import TextBlob

def get_sentiment(text):
    return TextBlob(text).sentiment.polarity

# Calculate sentiment scores
for response_type in ['Initial Response', 'Thank You Response']:
    gpt_data[f'{response_type}_sentiment'] = gpt_data[response_type].apply(get_sentiment)
    gemini_data[f'{response_type}_sentiment'] = gemini_data[response_type].apply(get_sentiment)

plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
data = pd.DataFrame({
    'GPT': gpt_data['Initial Response_sentiment'],
    'Gemini': gemini_data['Initial Response_sentiment']
})
sns.violinplot(data=data)
plt.title('Initial Response Sentiment Distribution')
plt.ylabel('Sentiment Score')

plt.subplot(1, 2, 2)
data = pd.DataFrame({
    'GPT': gpt_data['Thank You Response_sentiment'],
    'Gemini': gemini_data['Thank You Response_sentiment']
})
sns.violinplot(data=data)
plt.title('Thank You Response Sentiment Distribution')
plt.ylabel('Sentiment Score')
plt.tight_layout()
plt.savefig('_polite_analysis/figures/sentiment_distribution.png')
plt.close()

# 3. Correlation Analysis Visualization
plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
plt.scatter(gpt_data['Initial Response_length'], gpt_data['Initial Response_sentiment'], 
           alpha=0.5, label='GPT', color='blue')
plt.scatter(gemini_data['Initial Response_length'], gemini_data['Initial Response_sentiment'], 
           alpha=0.5, label='Gemini', color='orange')
plt.title('Initial Response: Length vs Sentiment')
plt.xlabel('Response Length')
plt.ylabel('Sentiment Score')
plt.legend()

plt.subplot(1, 2, 2)
plt.scatter(gpt_data['Thank You Response_length'], gpt_data['Thank You Response_sentiment'], 
           alpha=0.5, label='GPT', color='blue')
plt.scatter(gemini_data['Thank You Response_length'], gemini_data['Thank You Response_sentiment'], 
           alpha=0.5, label='Gemini', color='orange')
plt.title('Thank You Response: Length vs Sentiment')
plt.xlabel('Response Length')
plt.ylabel('Sentiment Score')
plt.legend()
plt.tight_layout()
plt.savefig('_polite_analysis/figures/length_sentiment_correlation.png')
plt.close()

# 4. Response Pattern Consistency
plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
plt.scatter(gpt_data['Initial Response_length'], gpt_data['Thank You Response_length'], 
           alpha=0.5, label='GPT', color='blue')
plt.scatter(gemini_data['Initial Response_length'], gemini_data['Thank You Response_length'], 
           alpha=0.5, label='Gemini', color='orange')
plt.title('Initial vs Thank You Response Length')
plt.xlabel('Initial Response Length')
plt.ylabel('Thank You Response Length')
plt.legend()

plt.subplot(1, 2, 2)
plt.scatter(gpt_data['Initial Response_sentiment'], gpt_data['Thank You Response_sentiment'], 
           alpha=0.5, label='GPT', color='blue')
plt.scatter(gemini_data['Initial Response_sentiment'], gemini_data['Thank You Response_sentiment'], 
           alpha=0.5, label='Gemini', color='orange')
plt.title('Initial vs Thank You Response Sentiment')
plt.xlabel('Initial Response Sentiment')
plt.ylabel('Thank You Response Sentiment')
plt.legend()
plt.tight_layout()
plt.savefig('_polite_analysis/figures/response_pattern_consistency.png')
plt.close()

# 5. Statistical Significance Visualization
def calculate_effect_size(group1, group2):
    n1, n2 = len(group1), len(group2)
    var1, var2 = np.var(group1, ddof=1), np.var(group2, ddof=1)
    pooled_se = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
    return (np.mean(group1) - np.mean(group2)) / pooled_se

# Calculate effect sizes
effect_sizes = {
    'Initial Length': calculate_effect_size(gpt_data['Initial Response_length'], 
                                          gemini_data['Initial Response_length']),
    'Thank You Length': calculate_effect_size(gpt_data['Thank You Response_length'], 
                                            gemini_data['Thank You Response_length']),
    'Initial Sentiment': calculate_effect_size(gpt_data['Initial Response_sentiment'], 
                                             gemini_data['Initial Response_sentiment']),
    'Thank You Sentiment': calculate_effect_size(gpt_data['Thank You Response_sentiment'], 
                                               gemini_data['Thank You Response_sentiment'])
}

plt.figure(figsize=(10, 6))
bars = plt.bar(effect_sizes.keys(), effect_sizes.values())
plt.axhline(y=0.2, color='r', linestyle='--', label='Small effect')
plt.axhline(y=0.5, color='g', linestyle='--', label='Medium effect')
plt.title('Effect Sizes for Different Measures')
plt.ylabel("Cohen's d")
plt.xticks(rotation=45)

# Add value labels on top of bars
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height,
             f'{height:.3f}',
             ha='center', va='bottom')

plt.legend()
plt.tight_layout()
plt.savefig('_polite_analysis/figures/effect_sizes.png')
plt.close()

print("Statistical visualizations have been generated and saved in _polite_analysis/figures/") 