import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import nltk
from textblob import TextBlob

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

def load_data():
    """Load GPT and Gemini response data."""
    gpt_df = pd.read_csv('emotion_gpt_analysis.csv')
    gemini_df = pd.read_csv('emotion_gemini_analysis.csv')
    return gpt_df, gemini_df

def preprocess_text(text):
    """Preprocess text for word analysis."""
    if not isinstance(text, str):
        return []
    
    # Tokenize and convert to lowercase
    words = word_tokenize(text.lower())
    
    # Remove stopwords and non-alphabetic characters
    stop_words = set(stopwords.words('english'))
    words = [word for word in words if word.isalpha() and word not in stop_words]
    
    return words

def analyze_word_frequency(texts, top_n=20):
    """Analyze word frequency in a list of texts."""
    all_words = []
    for text in texts:
        all_words.extend(preprocess_text(text))
    
    word_freq = Counter(all_words)
    return word_freq.most_common(top_n)

def calculate_word_statistics(texts):
    """Calculate word statistics for a list of texts."""
    word_lengths = []
    word_counts = []
    
    for text in texts:
        words = preprocess_text(text)
        word_lengths.extend([len(word) for word in words])
        word_counts.append(len(words))
    
    return {
        'avg_word_length': np.mean(word_lengths),
        'std_word_length': np.std(word_lengths),
        'avg_word_count': np.mean(word_counts),
        'std_word_count': np.std(word_counts)
    }

def perform_paired_t_test(gpt_stats, gemini_stats):
    """Perform paired t-test on word statistics."""
    # Prepare data for t-test
    gpt_word_counts = [len(preprocess_text(text)) for text in gpt_stats]
    gemini_word_counts = [len(preprocess_text(text)) for text in gemini_stats]
    
    # Perform t-test
    t_stat, p_value = stats.ttest_rel(gpt_word_counts, gemini_word_counts)
    
    return {
        't_statistic': t_stat,
        'p_value': p_value,
        'significant': p_value < 0.05
    }

def plot_word_distributions(gpt_df, gemini_df):
    """Plot word count distributions for both models."""
    plt.figure(figsize=(12, 6))
    
    # Calculate word counts
    gpt_word_counts = [len(preprocess_text(text)) for text in gpt_df['Emotional Response']]
    gemini_word_counts = [len(preprocess_text(text)) for text in gemini_df['Emotional Response']]
    
    # Create violin plot
    data = [gpt_word_counts, gemini_word_counts]
    sns.violinplot(data=data)
    plt.xticks([0, 1], ['GPT', 'Gemini'])
    plt.ylabel('Word Count')
    plt.title('Word Count Distribution Comparison')
    plt.savefig('scripts/word_count_distribution.png')
    plt.close()

def plot_word_frequency_comparison(gpt_df, gemini_df, top_n=20):
    """Plot comparison of most frequent words."""
    # Get word frequencies
    gpt_words = analyze_word_frequency(gpt_df['Emotional Response'], top_n)
    gemini_words = analyze_word_frequency(gemini_df['Emotional Response'], top_n)
    
    # Create DataFrame for plotting
    words_df = pd.DataFrame({
        'Word': [word for word, _ in gpt_words + gemini_words],
        'Frequency': [freq for _, freq in gpt_words + gemini_words],
        'Model': ['GPT'] * top_n + ['Gemini'] * top_n
    })
    
    # Plot
    plt.figure(figsize=(15, 8))
    sns.barplot(data=words_df, x='Word', y='Frequency', hue='Model')
    plt.xticks(rotation=45, ha='right')
    plt.title('Most Frequent Words Comparison')
    plt.tight_layout()
    plt.savefig('scripts/word_frequency_comparison.png')
    plt.close()

def analyze_word_diversity(gpt_df, gemini_df):
    """Analyze word diversity using various metrics."""
    def calculate_diversity(texts):
        all_words = []
        for text in texts:
            all_words.extend(preprocess_text(text))
        
        unique_words = set(all_words)
        total_words = len(all_words)
        
        return {
            'unique_words': len(unique_words),
            'total_words': total_words,
            'diversity_ratio': len(unique_words) / total_words if total_words > 0 else 0
        }
    
    gpt_diversity = calculate_diversity(gpt_df['Emotional Response'])
    gemini_diversity = calculate_diversity(gemini_df['Emotional Response'])
    
    return {
        'GPT': gpt_diversity,
        'Gemini': gemini_diversity
    }

def main():
    # Load data
    gpt_df, gemini_df = load_data()
    
    # Calculate word statistics
    gpt_stats = calculate_word_statistics(gpt_df['Emotional Response'])
    gemini_stats = calculate_word_statistics(gemini_df['Emotional Response'])
    
    # Perform paired t-test
    t_test_results = perform_paired_t_test(
        gpt_df['Emotional Response'],
        gemini_df['Emotional Response']
    )
    
    # Analyze word diversity
    diversity_results = analyze_word_diversity(gpt_df, gemini_df)
    
    # Generate visualizations
    plot_word_distributions(gpt_df, gemini_df)
    plot_word_frequency_comparison(gpt_df, gemini_df)
    
    # Save results
    with open('scripts/word_usage_analysis.txt', 'w') as f:
        f.write("Word Usage Analysis Results\n")
        f.write("=========================\n\n")
        
        f.write("Word Statistics:\n")
        f.write("---------------\n")
        f.write("GPT:\n")
        for key, value in gpt_stats.items():
            f.write(f"{key}: {value:.3f}\n")
        f.write("\nGemini:\n")
        for key, value in gemini_stats.items():
            f.write(f"{key}: {value:.3f}\n")
        
        f.write("\nPaired T-Test Results:\n")
        f.write("--------------------\n")
        f.write(f"t-statistic: {t_test_results['t_statistic']:.3f}\n")
        f.write(f"p-value: {t_test_results['p_value']:.3f}\n")
        f.write(f"Significant difference: {t_test_results['significant']}\n")
        
        f.write("\nWord Diversity Analysis:\n")
        f.write("----------------------\n")
        for model, stats in diversity_results.items():
            f.write(f"\n{model}:\n")
            for key, value in stats.items():
                f.write(f"{key}: {value}\n")
        
        f.write("\nMost Frequent Words:\n")
        f.write("------------------\n")
        f.write("GPT:\n")
        for word, freq in analyze_word_frequency(gpt_df['Emotional Response'], 10):
            f.write(f"{word}: {freq}\n")
        f.write("\nGemini:\n")
        for word, freq in analyze_word_frequency(gemini_df['Emotional Response'], 10):
            f.write(f"{word}: {freq}\n")

if __name__ == "__main__":
    main() 