# Guide to Sentiment Analysis

This guide explains how to perform sentiment analysis on text data, using our implementation as an example.

## 1. Understanding Sentiment Analysis

Sentiment analysis (also known as opinion mining) is the process of determining the emotional tone or attitude expressed in text. It involves:

- Identifying whether text is positive, negative, or neutral
- Measuring the intensity of the sentiment
- Analyzing the subjectivity of the language
- Detecting emotional patterns and themes

## 2. Tools and Libraries

For our analysis, we used:
- **TextBlob**: For basic sentiment and subjectivity analysis
- **NLTK**: For text preprocessing and word tokenization
- **Pandas**: For data manipulation and analysis
- **Matplotlib/Seaborn**: For visualization

## 3. Step-by-Step Implementation

### 3.1 Data Preparation

```python
def load_data():
    """Load and prepare the emotion analysis datasets."""
    gpt_df = pd.read_csv('emotion_gpt_analysis.csv')
    gemini_df = pd.read_csv('emotion_gemini_analysis.csv')
    return gpt_df, gemini_df
```

- Load your text data into a structured format (e.g., CSV)
- Ensure text is clean and properly formatted
- Handle missing values and edge cases

### 3.2 Basic Sentiment Analysis

```python
def analyze_sentiment(text):
    """Analyze sentiment of text using TextBlob."""
    if isinstance(text, str):
        return TextBlob(text).sentiment.polarity
    return 0
```

- Use TextBlob's sentiment analyzer
- Returns a value between -1 (very negative) and +1 (very positive)
- Handle non-string inputs gracefully

### 3.3 Subjectivity Analysis

```python
def analyze_sentiment_subjectivity(text):
    """Analyze subjectivity of text using TextBlob."""
    if isinstance(text, str):
        return TextBlob(text).sentiment.subjectivity
    return 0
```

- Measures how subjective vs. objective the language is
- Returns a value between 0 (completely objective) and 1 (completely subjective)
- Helps understand the emotional intensity of the text

### 3.4 Emotional Pattern Analysis

```python
def get_emotional_words(text):
    """Extract emotional words from text."""
    emotional_words = {
        'positive': ['happy', 'good', 'great', 'wonderful', 'excellent', 'positive', 'support', 'help', 'understand'],
        'negative': ['sad', 'bad', 'difficult', 'hard', 'negative', 'problem', 'worried', 'anxious'],
        'empathy': ['feel', 'understand', 'hear', 'sense', 'know'],
        'support': ['support', 'help', 'here', 'listen', 'care'],
        'validation': ['okay', 'normal', 'natural', 'valid', 'fine'],
        'encouragement': ['remember', 'important', 'strong', 'capable', 'can']
    }
    
    if not isinstance(text, str):
        return {k: 0 for k in emotional_words.keys()}
    
    text = text.lower()
    words = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    words = [w for w in words if w not in stop_words]
    
    patterns = {}
    for category, word_list in emotional_words.items():
        patterns[category] = sum(1 for word in words if word in word_list)
    
    return patterns
```

- Define categories of emotional words
- Preprocess text (lowercase, tokenization, remove stopwords)
- Count occurrences of emotional words in each category
- Returns a dictionary of emotional pattern frequencies

### 3.5 Distribution Analysis

```python
def analyze_sentiment_distribution(df, model_name):
    """Analyze sentiment distribution."""
    sentiment_stats = df['Sentiment'].describe()
    subjectivity_stats = df['Subjectivity'].describe()
    
    # Create sentiment distribution plot
    plt.figure(figsize=(10, 6))
    sns.histplot(data=df, x='Sentiment', bins=30)
    plt.title(f'Sentiment Distribution - {model_name}')
    plt.savefig(f'scripts/sentiment_dist_{model_name.lower()}.png')
    
    # Create subjectivity distribution plot
    plt.figure(figsize=(10, 6))
    sns.histplot(data=df, x='Subjectivity', bins=30)
    plt.title(f'Subjectivity Distribution - {model_name}')
    plt.savefig(f'scripts/subjectivity_dist_{model_name.lower()}.png')
    
    return sentiment_stats, subjectivity_stats
```

- Calculate statistical measures (mean, median, std dev, etc.)
- Create visualizations of distributions
- Save plots for later analysis

### 3.6 Emotional Pattern Analysis

```python
def analyze_emotional_patterns(df, model_name):
    """Analyze emotional word patterns."""
    emotional_patterns = pd.DataFrame(df['Emotional_Patterns'].tolist())
    pattern_stats = emotional_patterns.describe()
    
    # Create emotional patterns heatmap
    plt.figure(figsize=(12, 8))
    sns.heatmap(emotional_patterns.corr(), annot=True, cmap='coolwarm')
    plt.title(f'Emotional Pattern Correlations - {model_name}')
    plt.savefig(f'scripts/emotional_patterns_{model_name.lower()}.png')
    
    return pattern_stats
```

- Convert emotional patterns to a DataFrame
- Calculate statistics for each emotional category
- Create correlation heatmap to visualize relationships
- Save visualization for later analysis

## 4. Advanced Sentiment Analysis Techniques

### 4.1 Aspect-Based Sentiment Analysis

Instead of analyzing overall sentiment, you can analyze sentiment toward specific aspects:

```python
def aspect_sentiment(text, aspect):
    """Analyze sentiment toward a specific aspect."""
    # Find sentences mentioning the aspect
    sentences = TextBlob(text).sentences
    aspect_sentences = [s for s in sentences if aspect.lower() in s.lower()]
    
    if not aspect_sentences:
        return 0
    
    # Calculate average sentiment for these sentences
    return sum(s.sentiment.polarity for s in aspect_sentences) / len(aspect_sentences)
```

### 4.2 Emotion Detection

For more nuanced analysis, you can detect specific emotions:

```python
def detect_emotions(text):
    """Detect specific emotions in text."""
    emotions = {
        'joy': ['happy', 'joy', 'delighted', 'excited', 'pleased'],
        'sadness': ['sad', 'unhappy', 'depressed', 'down', 'disappointed'],
        'anger': ['angry', 'furious', 'annoyed', 'irritated', 'mad'],
        'fear': ['afraid', 'scared', 'fearful', 'worried', 'anxious'],
        'surprise': ['surprised', 'amazed', 'astonished', 'shocked'],
        'disgust': ['disgusted', 'revolted', 'dislike', 'hate', 'loathe']
    }
    
    if not isinstance(text, str):
        return {k: 0 for k in emotions.keys()}
    
    text = text.lower()
    words = word_tokenize(text)
    
    detected = {}
    for emotion, word_list in emotions.items():
        detected[emotion] = sum(1 for word in words if word in word_list)
    
    return detected
```

### 4.3 Sentiment Analysis with Machine Learning

For more accurate results, you can train a custom sentiment classifier:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

def train_sentiment_classifier(texts, labels):
    """Train a custom sentiment classifier."""
    # Vectorize text
    vectorizer = TfidfVectorizer(max_features=5000)
    X = vectorizer.fit_transform(texts)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)
    
    # Train model
    model = LogisticRegression()
    model.fit(X_train, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    
    return model, vectorizer, accuracy, report
```

## 5. Best Practices

1. **Preprocessing**:
   - Clean text (remove HTML, special characters)
   - Handle contractions and abbreviations
   - Normalize text (lowercase, stemming/lemmatization)
   - Remove stopwords when appropriate

2. **Validation**:
   - Use multiple sentiment analyzers for comparison
   - Validate results against human annotations
   - Consider domain-specific sentiment

3. **Interpretation**:
   - Consider context when interpreting results
   - Be aware of sarcasm and irony
   - Account for cultural differences in expression

4. **Visualization**:
   - Use appropriate visualizations for different aspects
   - Include confidence intervals when possible
   - Highlight key findings

## 6. Common Challenges

1. **Sarcasm and Irony**: These are difficult to detect automatically
2. **Context Dependency**: The same words can have different sentiment in different contexts
3. **Cultural Differences**: Sentiment expressions vary across cultures
4. **Negation Handling**: "Not good" should be treated differently from "good"
5. **Domain Specificity**: General sentiment analyzers may not work well for specialized domains

## 7. Conclusion

Sentiment analysis is a powerful tool for understanding emotional content in text. By combining basic sentiment analysis with more advanced techniques like emotional pattern detection and aspect-based analysis, you can gain deeper insights into the emotional landscape of your text data.

Remember that sentiment analysis is not perfect, and results should be interpreted with caution, especially when dealing with complex language patterns like sarcasm or cultural nuances. 