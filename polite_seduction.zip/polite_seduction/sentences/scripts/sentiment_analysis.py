import pandas as pd
import numpy as np
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import re

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

def load_data():
    """Load and prepare the emotion analysis datasets."""
    gpt_df = pd.read_csv('emotion_gpt_analysis.csv')
    gemini_df = pd.read_csv('emotion_gemini_analysis.csv')
    return gpt_df, gemini_df

def analyze_sentiment(text):
    """Analyze sentiment of text using TextBlob."""
    if isinstance(text, str):
        return TextBlob(text).sentiment.polarity
    return 0

def analyze_sentiment_subjectivity(text):
    """Analyze subjectivity of text using TextBlob."""
    if isinstance(text, str):
        return TextBlob(text).sentiment.subjectivity
    return 0

def get_emotional_words(text):
    """Extract emotional words from text."""
    emotional_words = {
        'positive': ['happy', 'good', 'great', 'wonderful', 'excellent', 'positive', 'support', 'help', 'understand'],
        'negative': ['sad', 'bad', 'difficult', 'hard', 'negative', 'problem', 'worried', 'anxious'],
        'empathy': ['feel', 'understand', 'hear', 'sense', 'know'],
        'support': ['support', 'help', 'here', 'listen', 'care'],
        'validation': ['okay', 'normal', 'natural', 'valid', 'fine'],
        'encouragement': ['remember', 'important', 'strong', 'capable', 'can']
    }
    
    if not isinstance(text, str):
        return {k: 0 for k in emotional_words.keys()}
    
    text = text.lower()
    words = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    words = [w for w in words if w not in stop_words]
    
    patterns = {}
    for category, word_list in emotional_words.items():
        patterns[category] = sum(1 for word in words if word in word_list)
    
    return patterns

def analyze_sentiment_distribution(df, model_name):
    """Analyze sentiment distribution."""
    sentiment_stats = df['Sentiment'].describe()
    subjectivity_stats = df['Subjectivity'].describe()
    
    # Create sentiment distribution plot
    plt.figure(figsize=(10, 6))
    sns.histplot(data=df, x='Sentiment', bins=30)
    plt.title(f'Sentiment Distribution - {model_name}')
    plt.savefig(f'scripts/sentiment_dist_{model_name.lower()}.png')
    
    # Create subjectivity distribution plot
    plt.figure(figsize=(10, 6))
    sns.histplot(data=df, x='Subjectivity', bins=30)
    plt.title(f'Subjectivity Distribution - {model_name}')
    plt.savefig(f'scripts/subjectivity_dist_{model_name.lower()}.png')
    
    return sentiment_stats, subjectivity_stats

def analyze_emotional_patterns(df, model_name):
    """Analyze emotional word patterns."""
    emotional_patterns = pd.DataFrame(df['Emotional_Patterns'].tolist())
    pattern_stats = emotional_patterns.describe()
    
    # Create emotional patterns heatmap
    plt.figure(figsize=(12, 8))
    sns.heatmap(emotional_patterns.corr(), annot=True, cmap='coolwarm')
    plt.title(f'Emotional Pattern Correlations - {model_name}')
    plt.savefig(f'scripts/emotional_patterns_{model_name.lower()}.png')
    
    return pattern_stats

def main():
    # Load data
    gpt_df, gemini_df = load_data()
    
    # Analyze sentiment and subjectivity
    gpt_df['Sentiment'] = gpt_df['Emotional Response'].apply(analyze_sentiment)
    gpt_df['Subjectivity'] = gpt_df['Emotional Response'].apply(analyze_sentiment_subjectivity)
    gemini_df['Sentiment'] = gemini_df['Emotional Response'].apply(analyze_sentiment)
    gemini_df['Subjectivity'] = gemini_df['Emotional Response'].apply(analyze_sentiment_subjectivity)
    
    # Analyze emotional patterns
    gpt_df['Emotional_Patterns'] = gpt_df['Emotional Response'].apply(get_emotional_words)
    gemini_df['Emotional_Patterns'] = gemini_df['Emotional Response'].apply(get_emotional_words)
    
    # Get statistics
    gpt_sentiment_stats, gpt_subjectivity_stats = analyze_sentiment_distribution(gpt_df, 'GPT')
    gemini_sentiment_stats, gemini_subjectivity_stats = analyze_sentiment_distribution(gemini_df, 'Gemini')
    
    gpt_pattern_stats = analyze_emotional_patterns(gpt_df, 'GPT')
    gemini_pattern_stats = analyze_emotional_patterns(gemini_df, 'Gemini')
    
    # Save results
    with open('scripts/sentiment_analysis_results.txt', 'w') as f:
        f.write("Sentiment Analysis Results\n")
        f.write("=======================\n\n")
        
        f.write("GPT Sentiment Statistics:\n")
        f.write(str(gpt_sentiment_stats))
        f.write("\n\nGPT Subjectivity Statistics:\n")
        f.write(str(gpt_subjectivity_stats))
        f.write("\n\nGPT Emotional Pattern Statistics:\n")
        f.write(str(gpt_pattern_stats))
        
        f.write("\n\nGemini Sentiment Statistics:\n")
        f.write(str(gemini_sentiment_stats))
        f.write("\n\nGemini Subjectivity Statistics:\n")
        f.write(str(gemini_subjectivity_stats))
        f.write("\n\nGemini Emotional Pattern Statistics:\n")
        f.write(str(gemini_pattern_stats))
        
        # Add comparative analysis
        f.write("\n\nComparative Analysis\n")
        f.write("------------------\n")
        f.write(f"Average Sentiment - GPT: {gpt_sentiment_stats['mean']:.3f}, Gemini: {gemini_sentiment_stats['mean']:.3f}\n")
        f.write(f"Average Subjectivity - GPT: {gpt_subjectivity_stats['mean']:.3f}, Gemini: {gemini_subjectivity_stats['mean']:.3f}\n")
        
        # Add emotional pattern comparison
        gpt_patterns = pd.DataFrame(gpt_df['Emotional_Patterns'].tolist()).mean()
        gemini_patterns = pd.DataFrame(gemini_df['Emotional_Patterns'].tolist()).mean()
        
        f.write("\nEmotional Pattern Comparison (Average occurrences per response):\n")
        for category in gpt_patterns.index:
            f.write(f"{category}: GPT={gpt_patterns[category]:.2f}, Gemini={gemini_patterns[category]:.2f}\n")

if __name__ == "__main__":
    main() 