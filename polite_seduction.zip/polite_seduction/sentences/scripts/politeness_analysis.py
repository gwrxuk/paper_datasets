import pandas as pd
import numpy as np
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from collections import Counter
import re

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

def load_data():
    """Load the politeness analysis CSV files"""
    gpt_df = pd.read_csv('polite_gpt_analysis.csv')
    gemini_df = pd.read_csv('polite_gemini_analysis.csv')
    return gpt_df, gemini_df

def analyze_politeness_patterns(text):
    """Analyze politeness markers in text"""
    # Define politeness categories and their associated words/phrases
    politeness_markers = {
        'greetings': ['hello', 'hi', 'good morning', 'good afternoon', 'good evening', 'hey'],
        'please': ['please', 'kindly', 'would you', 'could you'],
        'thank_you': ['thank you', 'thanks', 'appreciate', 'grateful'],
        'apology': ['sorry', 'apologize', 'excuse me', 'pardon'],
        'respect': ['sir', 'ma\'am', 'madam', 'mister', 'miss'],
        'hedging': ['maybe', 'perhaps', 'possibly', 'might', 'could', 'would'],
        'formality': ['regards', 'sincerely', 'best wishes', 'yours truly'],
        'indirectness': ['would you mind', 'if you could', 'if possible', 'when convenient']
    }
    
    # Initialize counters for each category
    counts = {category: 0 for category in politeness_markers}
    
    # Convert text to lowercase for matching
    text_lower = text.lower()
    
    # Count occurrences of each politeness marker
    for category, markers in politeness_markers.items():
        for marker in markers:
            counts[category] += len(re.findall(r'\b' + marker + r'\b', text_lower))
    
    return counts

def analyze_politeness_distribution(df, model_name):
    """Analyze the distribution of politeness patterns"""
    all_patterns = []
    
    for text in df['response']:
        patterns = analyze_politeness_patterns(text)
        all_patterns.append(patterns)
    
    # Convert to DataFrame
    patterns_df = pd.DataFrame(all_patterns)
    
    # Calculate statistics
    stats = {
        'mean': patterns_df.mean(),
        'std': patterns_df.std(),
        'median': patterns_df.median(),
        'min': patterns_df.min(),
        'max': patterns_df.max()
    }
    
    return patterns_df, stats

def visualize_politeness_patterns(gpt_patterns, gemini_patterns):
    """Create visualizations of politeness patterns"""
    # Set style
    plt.style.use('seaborn')
    
    # Create figure with subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Plot mean politeness patterns
    categories = gpt_patterns.columns
    x = np.arange(len(categories))
    width = 0.35
    
    ax1.bar(x - width/2, gpt_patterns.mean(), width, label='GPT', color='skyblue')
    ax1.bar(x + width/2, gemini_patterns.mean(), width, label='Gemini', color='lightgreen')
    
    ax1.set_ylabel('Average Occurrences')
    ax1.set_title('Average Politeness Patterns by Category')
    ax1.set_xticks(x)
    ax1.set_xticklabels(categories, rotation=45, ha='right')
    ax1.legend()
    
    # Plot distribution of total politeness markers
    gpt_total = gpt_patterns.sum(axis=1)
    gemini_total = gemini_patterns.sum(axis=1)
    
    sns.histplot(data=[gpt_total, gemini_total], label=['GPT', 'Gemini'], 
                bins=20, ax=ax2)
    ax2.set_xlabel('Total Politeness Markers')
    ax2.set_ylabel('Count')
    ax2.set_title('Distribution of Total Politeness Markers')
    ax2.legend()
    
    plt.tight_layout()
    plt.savefig('scripts/politeness_patterns.png')
    plt.close()

def main():
    # Load data
    gpt_df, gemini_df = load_data()
    
    # Analyze politeness patterns
    gpt_patterns, gpt_stats = analyze_politeness_distribution(gpt_df, 'GPT')
    gemini_patterns, gemini_stats = analyze_politeness_distribution(gemini_df, 'Gemini')
    
    # Create visualizations
    visualize_politeness_patterns(gpt_patterns, gemini_patterns)
    
    # Save results
    with open('scripts/politeness_analysis_results.txt', 'w') as f:
        f.write("POLITENESS ANALYSIS RESULTS\n")
        f.write("=========================\n\n")
        
        f.write("GPT POLITENESS STATISTICS\n")
        f.write("------------------------\n")
        for category, stats in gpt_stats.items():
            f.write(f"\n{category.upper()}:\n")
            for marker, value in stats.items():
                f.write(f"{marker}: {value:.3f}\n")
        
        f.write("\nGEMINI POLITENESS STATISTICS\n")
        f.write("---------------------------\n")
        for category, stats in gemini_stats.items():
            f.write(f"\n{category.upper()}:\n")
            for marker, value in stats.items():
                f.write(f"{marker}: {value:.3f}\n")
        
        # Add comparative analysis
        f.write("\nCOMPARATIVE ANALYSIS\n")
        f.write("-------------------\n")
        for category in gpt_patterns.columns:
            gpt_mean = gpt_patterns[category].mean()
            gemini_mean = gemini_patterns[category].mean()
            diff = gpt_mean - gemini_mean
            f.write(f"\n{category}:\n")
            f.write(f"GPT mean: {gpt_mean:.3f}\n")
            f.write(f"Gemini mean: {gemini_mean:.3f}\n")
            f.write(f"Difference (GPT - Gemini): {diff:.3f}\n")

if __name__ == "__main__":
    main() 