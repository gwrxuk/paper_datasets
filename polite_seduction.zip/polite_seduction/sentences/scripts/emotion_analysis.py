import pandas as pd
import numpy as np
from textblob import TextBlob
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from collections import Counter
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import re

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt_tab')

def load_data():
    """Load and prepare the emotion analysis datasets."""
    gpt_df = pd.read_csv('emotion_gpt_analysis.csv')
    gemini_df = pd.read_csv('emotion_gemini_analysis.csv')
    return gpt_df, gemini_df

def preprocess_text(text):
    """Clean and preprocess text data."""
    if isinstance(text, str):
        # Convert to lowercase
        text = text.lower()
        # Remove special characters and digits
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        # Tokenize
        tokens = word_tokenize(text)
        # Remove stopwords
        stop_words = set(stopwords.words('english'))
        tokens = [t for t in tokens if t not in stop_words]
        # Lemmatize
        lemmatizer = WordNetLemmatizer()
        tokens = [lemmatizer.lemmatize(t) for t in tokens]
        return ' '.join(tokens)
    return ''

def analyze_sentiment(text):
    """Analyze sentiment of text using TextBlob."""
    if isinstance(text, str):
        return TextBlob(text).sentiment.polarity
    return 0

def get_response_length(text):
    """Calculate response length in words."""
    if isinstance(text, str):
        return len(word_tokenize(text))
    return 0

def analyze_emotional_patterns(text):
    """Analyze emotional language patterns."""
    emotional_words = {
        'empathy': ['understand', 'hear', 'feel', 'sense'],
        'support': ['support', 'help', 'here', 'listen'],
        'validation': ['okay', 'normal', 'natural', 'valid'],
        'encouragement': ['remember', 'important', 'strong', 'capable']
    }
    
    if not isinstance(text, str):
        return {k: 0 for k in emotional_words.keys()}
    
    text = text.lower()
    patterns = {}
    for category, words in emotional_words.items():
        patterns[category] = sum(1 for word in words if word in text)
    return patterns

def perform_topic_modeling(texts, n_topics=5):
    """Perform topic modeling using LDA."""
    vectorizer = CountVectorizer(max_features=1000, stop_words='english')
    doc_term_matrix = vectorizer.fit_transform(texts)
    
    lda_model = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda_output = lda_model.fit_transform(doc_term_matrix)
    
    feature_names = vectorizer.get_feature_names_out()
    topics = []
    for topic_idx, topic in enumerate(lda_model.components_):
        top_words = [feature_names[i] for i in topic.argsort()[:-10:-1]]
        topics.append(top_words)
    
    return topics

def main():
    # Load data
    gpt_df, gemini_df = load_data()
    
    # Preprocess text
    gpt_df['Processed_Response'] = gpt_df['Emotional Response'].apply(preprocess_text)
    gemini_df['Processed_Response'] = gemini_df['Emotional Response'].apply(preprocess_text)
    
    # Analyze sentiment
    gpt_df['Sentiment'] = gpt_df['Emotional Response'].apply(analyze_sentiment)
    gemini_df['Sentiment'] = gemini_df['Emotional Response'].apply(analyze_sentiment)
    
    # Analyze response length
    gpt_df['Response_Length'] = gpt_df['Emotional Response'].apply(get_response_length)
    gemini_df['Response_Length'] = gemini_df['Emotional Response'].apply(get_response_length)
    
    # Analyze emotional patterns
    gpt_df['Emotional_Patterns'] = gpt_df['Emotional Response'].apply(analyze_emotional_patterns)
    gemini_df['Emotional_Patterns'] = gemini_df['Emotional Response'].apply(analyze_emotional_patterns)
    
    # Perform topic modeling
    gpt_topics = perform_topic_modeling(gpt_df['Processed_Response'])
    gemini_topics = perform_topic_modeling(gemini_df['Processed_Response'])
    
    # Save results
    results = {
        'gpt_sentiment_stats': gpt_df['Sentiment'].describe(),
        'gemini_sentiment_stats': gemini_df['Sentiment'].describe(),
        'gpt_length_stats': gpt_df['Response_Length'].describe(),
        'gemini_length_stats': gemini_df['Response_Length'].describe(),
        'gpt_topics': gpt_topics,
        'gemini_topics': gemini_topics
    }
    
    # Create visualizations
    plt.figure(figsize=(12, 6))
    data = [gpt_df['Sentiment'], gemini_df['Sentiment']]
    plt.boxplot(data)
    plt.xticks([1, 2], ['GPT', 'Gemini'])
    plt.title('Sentiment Distribution Comparison')
    plt.savefig('scripts/sentiment_distribution.png')
    
    plt.figure(figsize=(12, 6))
    data = [gpt_df['Response_Length'], gemini_df['Response_Length']]
    plt.boxplot(data)
    plt.xticks([1, 2], ['GPT', 'Gemini'])
    plt.title('Response Length Distribution')
    plt.savefig('scripts/response_length_distribution.png')
    
    # Save results to file
    with open('scripts/analysis_results.txt', 'w') as f:
        f.write("Text Mining and Content Analysis Results\n")
        f.write("=====================================\n\n")
        
        f.write("Sentiment Analysis\n")
        f.write("-----------------\n")
        f.write("GPT Sentiment Statistics:\n")
        f.write(str(results['gpt_sentiment_stats']))
        f.write("\n\nGemini Sentiment Statistics:\n")
        f.write(str(results['gemini_sentiment_stats']))
        
        f.write("\n\nResponse Length Analysis\n")
        f.write("----------------------\n")
        f.write("GPT Length Statistics:\n")
        f.write(str(results['gpt_length_stats']))
        f.write("\n\nGemini Length Statistics:\n")
        f.write(str(results['gemini_length_stats']))
        
        f.write("\n\nTopic Modeling Results\n")
        f.write("---------------------\n")
        f.write("GPT Topics:\n")
        for i, topic in enumerate(results['gpt_topics']):
            f.write(f"Topic {i+1}: {', '.join(topic)}\n")
        f.write("\nGemini Topics:\n")
        for i, topic in enumerate(results['gemini_topics']):
            f.write(f"Topic {i+1}: {', '.join(topic)}\n")

if __name__ == "__main__":
    main() 