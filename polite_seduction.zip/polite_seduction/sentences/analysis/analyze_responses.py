import pandas as pd
import numpy as np
from scipy import stats
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple
import re
import os

def calculate_effect_size(group1: np.ndarray, group2: np.ndarray) -> Tuple[float, str]:
    """
    Calculate Cohen's d effect size and interpret it.
    
    Returns:
        Tuple of (effect_size, interpretation)
    """
    # Calculate pooled standard deviation
    n1, n2 = len(group1), len(group2)
    var1, var2 = np.var(group1, ddof=1), np.var(group2, ddof=1)
    pooled_std = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
    
    # Calculate Cohen's d
    d = (np.mean(group1) - np.mean(group2)) / pooled_std
    
    # Interpret effect size
    if abs(d) < 0.2:
        interpretation = "Negligible effect"
    elif abs(d) < 0.5:
        interpretation = "Small effect"
    elif abs(d) < 0.8:
        interpretation = "Medium effect"
    else:
        interpretation = "Large effect"
        
    return d, interpretation

def extract_words(text: str) -> List[str]:
    """
    Extract words from text, removing punctuation and converting to lowercase.
    """
    if pd.isna(text):
        return []
    # Remove punctuation and convert to lowercase
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    # Split into words and remove empty strings
    return [word for word in text.split() if word]

def build_sentiment_categories(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame) -> Dict[str, List[str]]:
    """
    Build sentiment categories based on actual words used in responses.
    """
    # Initialize categories
    categories = {
        'positive': [],
        'negative': [],
        'neutral': [],
        'polite': [],
        'emotional': []
    }
    
    # Process both initial and thank you responses
    for df in [gpt_df, gemini_df]:
        for response_type in ['Initial Response', 'Thank You Response']:
            responses = df[response_type].dropna()
            for response in responses:
                words = extract_words(response)
                for word in words:
                    # Categorize words based on their usage context
                    if word in ['thank', 'appreciate', 'glad', 'happy', 'welcome', 'helpful', 'great', 'excellent', 'good', 'pleased', 'wonderful']:
                        categories['positive'].append(word)
                    elif word in ['sorry', 'unfortunately', 'cannot', 'unable', 'wrong', 'difficult', 'challenging', 'frustrating', 'regret']:
                        categories['negative'].append(word)
                    elif word in ['information', 'data', 'analysis', 'study', 'research', 'topic', 'subject', 'question', 'answer', 'explain', 'understand']:
                        categories['neutral'].append(word)
                    elif word in ['please', 'kindly', 'would', 'could', 'may', 'might', 'shall', 'should', 'let', 'allow']:
                        categories['polite'].append(word)
                    elif word in ['feel', 'emotion', 'heart', 'soul', 'spirit', 'passion', 'desire', 'hope', 'wish', 'dream', 'care', 'understand', 'support']:
                        categories['emotional'].append(word)
    
    # Get unique words and their frequencies for each category
    for category in categories:
        categories[category] = pd.Series(categories[category]).value_counts().to_dict()
    
    return categories

def analyze_responses(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame) -> Dict:
    """
    Perform comprehensive analysis of responses including comparisons between initial and thank you responses.
    """
    results = {}
    
    # Calculate response lengths
    for df in [gpt_df, gemini_df]:
        df['Initial Response Length'] = df['Initial Response'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
        df['Thank You Response Length'] = df['Thank You Response'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
        
        # Calculate sentiment scores
        df['Initial Sentiment'] = df['Initial Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
        df['Thank You Sentiment'] = df['Thank You Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
        
        # Calculate politeness scores
        politeness_words = ['please', 'thank', 'kindly', 'would', 'could', 'may', 'might']
        df['Initial Politeness'] = df['Initial Response'].apply(
            lambda x: sum(1 for word in politeness_words if word in str(x).lower()) if pd.notna(x) else 0
        )
        df['Thank You Politeness'] = df['Thank You Response'].apply(
            lambda x: sum(1 for word in politeness_words if word in str(x).lower()) if pd.notna(x) else 0
        )
    
    # Compare initial vs thank you responses for each model
    for model, df in [('GPT', gpt_df), ('Gemini', gemini_df)]:
        metrics = {
            'Response Length': ('Initial Response Length', 'Thank You Response Length'),
            'Sentiment Score': ('Initial Sentiment', 'Thank You Sentiment'),
            'Politeness Score': ('Initial Politeness', 'Thank You Politeness')
        }
        
        comparison_results = {}
        for metric, (initial_col, thank_you_col) in metrics.items():
            initial_data = df[initial_col]
            thank_you_data = df[thank_you_col]
            
            d, interpretation = calculate_effect_size(initial_data, thank_you_data)
            comparison_results[metric] = {
                'cohens_d': d,
                'interpretation': interpretation,
                'initial_mean': np.mean(initial_data),
                'thank_you_mean': np.mean(thank_you_data)
            }
        
        results[f'{model}_initial_vs_thank_you'] = comparison_results
    
    # Compare GPT vs Gemini for initial responses
    initial_comparison = {}
    for metric, (gpt_col, gemini_col) in [
        ('Response Length', ('Initial Response Length', 'Initial Response Length')),
        ('Sentiment Score', ('Initial Sentiment', 'Initial Sentiment')),
        ('Politeness Score', ('Initial Politeness', 'Initial Politeness'))
    ]:
        gpt_data = gpt_df[gpt_col]
        gemini_data = gemini_df[gemini_col]
        
        d, interpretation = calculate_effect_size(gpt_data, gemini_data)
        initial_comparison[metric] = {
            'cohens_d': d,
            'interpretation': interpretation,
            'gpt_mean': np.mean(gpt_data),
            'gemini_mean': np.mean(gemini_data)
        }
    
    results['initial_gpt_vs_gemini'] = initial_comparison
    
    # Compare GPT vs Gemini for thank you responses
    thank_you_comparison = {}
    for metric, (gpt_col, gemini_col) in [
        ('Response Length', ('Thank You Response Length', 'Thank You Response Length')),
        ('Sentiment Score', ('Thank You Sentiment', 'Thank You Sentiment')),
        ('Politeness Score', ('Thank You Politeness', 'Thank You Politeness'))
    ]:
        gpt_data = gpt_df[gpt_col]
        gemini_data = gemini_df[gemini_col]
        
        d, interpretation = calculate_effect_size(gpt_data, gemini_data)
        thank_you_comparison[metric] = {
            'cohens_d': d,
            'interpretation': interpretation,
            'gpt_mean': np.mean(gpt_data),
            'gemini_mean': np.mean(gemini_data)
        }
    
    results['thank_you_gpt_vs_gemini'] = thank_you_comparison
    
    # Build sentiment categories from actual responses
    results['sentiment_categories'] = build_sentiment_categories(gpt_df, gemini_df)
    
    return results

def plot_comparisons(results: Dict):
    """
    Create visualizations for the comparisons.
    """
    # Plot initial vs thank you responses for each model
    for model in ['GPT', 'Gemini']:
        plt.figure(figsize=(12, 6))
        metrics = list(results[f'{model}_initial_vs_thank_you'].keys())
        x = np.arange(len(metrics))
        width = 0.35
        
        initial_means = [results[f'{model}_initial_vs_thank_you'][m]['initial_mean'] for m in metrics]
        thank_you_means = [results[f'{model}_initial_vs_thank_you'][m]['thank_you_mean'] for m in metrics]
        
        plt.bar(x - width/2, initial_means, width, label='Initial Response')
        plt.bar(x + width/2, thank_you_means, width, label='Thank You Response')
        
        plt.xlabel('Metrics')
        plt.ylabel('Score')
        plt.title(f'{model} - Initial vs Thank You Response Comparison')
        plt.xticks(x, metrics, rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.savefig(f'_polite_analysis/figures/{model.lower()}_initial_vs_thank_you.png')
        plt.close()
    
    # Plot GPT vs Gemini comparisons
    for response_type in ['initial', 'thank_you']:
        plt.figure(figsize=(12, 6))
        metrics = list(results[f'{response_type}_gpt_vs_gemini'].keys())
        x = np.arange(len(metrics))
        width = 0.35
        
        gpt_means = [results[f'{response_type}_gpt_vs_gemini'][m]['gpt_mean'] for m in metrics]
        gemini_means = [results[f'{response_type}_gpt_vs_gemini'][m]['gemini_mean'] for m in metrics]
        
        plt.bar(x - width/2, gpt_means, width, label='GPT')
        plt.bar(x + width/2, gemini_means, width, label='Gemini')
        
        plt.xlabel('Metrics')
        plt.ylabel('Score')
        plt.title(f'GPT vs Gemini - {response_type.title()} Response Comparison')
        plt.xticks(x, metrics, rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.savefig(f'_polite_analysis/figures/{response_type}_gpt_vs_gemini.png')
        plt.close()

def plot_sentiment_categories(sentiment_categories: Dict):
    """
    Create visualizations for sentiment categories.
    """
    plt.figure(figsize=(15, 10))
    
    categories = ['positive', 'negative', 'neutral', 'polite', 'emotional']
    for i, category in enumerate(categories, 1):
        plt.subplot(2, 3, i)
        data = sentiment_categories[category]
        
        if data:
            # Get top 10 words
            words = list(data.keys())[:10]
            frequencies = list(data.values())[:10]
            
            plt.barh(words, frequencies)
            plt.title(f'{category.capitalize()} Words')
            plt.xlabel('Frequency')
        else:
            plt.text(0.5, 0.5, 'No words found', 
                    ha='center', va='center')
            plt.title(f'{category.capitalize()} Words')
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/sentiment_categories.png')
    plt.close()

def perform_statistical_tests(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame) -> Dict:
    """
    Perform statistical tests including paired t-tests and distribution analysis.
    """
    stats_results = {}
    
    # Paired t-test for initial vs thank you responses
    for model, df in [('GPT', gpt_df), ('Gemini', gemini_df)]:
        initial_sentiment = df['Initial Sentiment'].dropna()
        thank_you_sentiment = df['Thank You Sentiment'].dropna()
        
        t_stat, p_value = stats.ttest_rel(initial_sentiment, thank_you_sentiment)
        stats_results[f'{model}_paired_ttest'] = {
            't_statistic': t_stat,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
        
        # Distribution statistics
        stats_results[f'{model}_distribution'] = {
            'initial': {
                'mean': np.mean(initial_sentiment),
                'std': np.std(initial_sentiment),
                'skew': stats.skew(initial_sentiment),
                'kurtosis': stats.kurtosis(initial_sentiment)
            },
            'thank_you': {
                'mean': np.mean(thank_you_sentiment),
                'std': np.std(thank_you_sentiment),
                'skew': stats.skew(thank_you_sentiment),
                'kurtosis': stats.kurtosis(thank_you_sentiment)
            }
        }
    
    # Independent t-test for GPT vs Gemini
    for response_type in ['Initial', 'Thank You']:
        gpt_data = gpt_df[f'{response_type} Sentiment'].dropna()
        gemini_data = gemini_df[f'{response_type} Sentiment'].dropna()
        
        t_stat, p_value = stats.ttest_ind(gpt_data, gemini_data)
        stats_results[f'{response_type.lower()}_gpt_vs_gemini'] = {
            't_statistic': t_stat,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
    
    return stats_results

def create_distribution_plots(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame):
    """
    Create distribution plots for sentiment scores.
    """
    # Create figure with subplots
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Distribution of Sentiment Scores', fontsize=16)
    
    # GPT Initial vs Thank You
    sns.histplot(data=gpt_df, x='Initial Sentiment', kde=True, ax=axes[0,0], label='Initial')
    sns.histplot(data=gpt_df, x='Thank You Sentiment', kde=True, ax=axes[0,0], label='Thank You')
    axes[0,0].set_title('GPT - Initial vs Thank You Response Distribution')
    axes[0,0].legend()
    
    # Gemini Initial vs Thank You
    sns.histplot(data=gemini_df, x='Initial Sentiment', kde=True, ax=axes[0,1], label='Initial')
    sns.histplot(data=gemini_df, x='Thank You Sentiment', kde=True, ax=axes[0,1], label='Thank You')
    axes[0,1].set_title('Gemini - Initial vs Thank You Response Distribution')
    axes[0,1].legend()
    
    # GPT vs Gemini Initial
    sns.histplot(data=gpt_df, x='Initial Sentiment', kde=True, ax=axes[1,0], label='GPT')
    sns.histplot(data=gemini_df, x='Initial Sentiment', kde=True, ax=axes[1,0], label='Gemini')
    axes[1,0].set_title('GPT vs Gemini - Initial Response Distribution')
    axes[1,0].legend()
    
    # GPT vs Gemini Thank You
    sns.histplot(data=gpt_df, x='Thank You Sentiment', kde=True, ax=axes[1,1], label='GPT')
    sns.histplot(data=gemini_df, x='Thank You Sentiment', kde=True, ax=axes[1,1], label='Gemini')
    axes[1,1].set_title('GPT vs Gemini - Thank You Response Distribution')
    axes[1,1].legend()
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/distribution_plots.png')
    plt.close()

def create_effect_size_plot(results: Dict):
    """
    Create a bar plot comparing effect sizes.
    """
    plt.figure(figsize=(12, 6))
    
    # Extract effect sizes
    models = ['GPT', 'Gemini']
    metrics = ['Response Length', 'Sentiment Score', 'Politeness Score']
    
    x = np.arange(len(metrics))
    width = 0.35
    
    for i, model in enumerate(models):
        effect_sizes = [results[f'{model}_initial_vs_thank_you'][metric]['cohens_d'] for metric in metrics]
        plt.bar(x + i*width, effect_sizes, width, label=model)
    
    plt.xlabel('Metrics')
    plt.ylabel("Cohen's d Effect Size")
    plt.title('Effect Sizes by Model and Metric')
    plt.xticks(x + width/2, metrics)
    plt.legend()
    
    # Add reference lines for effect size interpretation
    plt.axhline(y=0.2, color='r', linestyle='--', alpha=0.3, label='Small Effect (0.2)')
    plt.axhline(y=0.5, color='g', linestyle='--', alpha=0.3, label='Medium Effect (0.5)')
    plt.axhline(y=0.8, color='b', linestyle='--', alpha=0.3, label='Large Effect (0.8)')
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/effect_sizes.png')
    plt.close()

def create_sentiment_category_plot(sentiment_categories: Dict):
    """
    Create a stacked bar plot for sentiment categories.
    """
    plt.figure(figsize=(12, 6))
    
    categories = ['positive', 'negative', 'neutral', 'polite', 'emotional']
    words = []
    frequencies = []
    
    for category in categories:
        if category in sentiment_categories:
            category_words = list(sentiment_categories[category].keys())[:5]  # Top 5 words
            category_freqs = list(sentiment_categories[category].values())[:5]
            words.extend([f"{word} ({category})" for word in category_words])
            frequencies.extend(category_freqs)
    
    plt.barh(words, frequencies)
    plt.xlabel('Frequency')
    plt.ylabel('Words by Category')
    plt.title('Top Words in Each Sentiment Category')
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/sentiment_categories.png')
    plt.close()

def calculate_word_count(text: str) -> int:
    """
    Calculate the number of words in a text.
    """
    if pd.isna(text):
        return 0
    # Remove punctuation and convert to lowercase
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    # Split into words and remove empty strings
    return len([word for word in text.split() if word])

def generate_html_report(results: Dict, sentiment_categories: Dict, stats_results: Dict):
    """
    Generate a comprehensive HTML report of the analysis results.
    """
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Polite Response Analysis Results</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1, h2, h3, h4 { color: #2c3e50; }
            .section { margin: 20px 0; padding: 20px; background-color: #f8f9fa; border-radius: 5px; }
            .metric { margin: 10px 0; }
            .effect-size { color: #2980b9; }
            .interpretation { color: #27ae60; }
            .significant { color: #e74c3c; font-weight: bold; }
            .not-significant { color: #7f8c8d; }
            table { border-collapse: collapse; width: 100%; margin: 10px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .comparison-table { margin: 20px 0; }
            .comparison-table th { background-color: #e8f4f8; }
            .comparison-table td.highlight { background-color: #f8f9fa; }
            .positive-sentiment { color: #27ae60; }
            .negative-sentiment { color: #e74c3c; }
            .word-list { margin: 15px 0; }
            .word-category { margin: 10px 0; }
            .word-category h4 { color: #2c3e50; margin-bottom: 5px; }
            .word-list ul { list-style-type: none; padding-left: 0; }
            .word-list li { display: inline-block; margin: 3px; padding: 3px 8px; background-color: #f8f9fa; border-radius: 3px; }
            .sentiment-category { margin: 15px 0; }
            .word-frequency { margin-left: 20px; }
            .references { margin-top: 30px; }
            .reference-item { margin: 10px 0; }
            .visualization { margin: 20px 0; text-align: center; }
            .visualization img { max-width: 100%; height: auto; }
            .visualization-caption { margin-top: 10px; font-style: italic; color: #666; }
            .methodology { margin: 15px 0; padding: 15px; background-color: #fff; border-left: 4px solid #2980b9; }
            .methodology h4 { margin-top: 0; }
            .methodology ul { margin: 10px 0; }
            .methodology li { margin: 5px 0; }
            .formula { font-family: "Times New Roman", serif; font-style: italic; }
            .calculation-steps { margin-left: 20px; }
            .step { margin: 10px 0; }
            .step-number { font-weight: bold; color: #2980b9; }
            .example { background-color: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0; }
        </style>
    </head>
    <body>
        <h1>Polite Response Analysis Results</h1>
        
        <div class="section">
            <h2>Comprehensive Response Comparison</h2>
            <div class="comparison-table">
                <table>
                    <tr>
                        <th>Model</th>
                        <th>Response Type</th>
                        <th>Sentiment Polarity (-1 to +1)</th>
                        <th>Emotional Words Count</th>
                        <th>Politeness Markers</th>
                        <th>Avg Words per Response</th>
                    </tr>
    """
    
    # Add rows for GPT and Gemini comparisons
    for model_key in ['GPT_initial_vs_thank_you', 'Gemini_initial_vs_thank_you']:
        model = model_key.split('_')[0]
        model_stats = results[model_key]
        
        # Initial response stats
        initial_sentiment = model_stats['Sentiment Score']['initial_mean']
        initial_sentiment_class = 'positive-sentiment' if initial_sentiment > 0 else 'negative-sentiment'
        
        # Thank you response stats
        thank_you_sentiment = model_stats['Sentiment Score']['thank_you_mean']
        thank_you_sentiment_class = 'positive-sentiment' if thank_you_sentiment > 0 else 'negative-sentiment'
        
        # Calculate average word counts
        initial_word_count = model_stats['Response Length']['initial_mean']
        thank_you_word_count = model_stats['Response Length']['thank_you_mean']
        
        # Add initial response row
        html_content += f"""
                    <tr>
                        <td class="highlight">{model}</td>
                        <td class="highlight">Initial</td>
                        <td class="{initial_sentiment_class}">{initial_sentiment:.3f}</td>
                        <td>{model_stats['Response Length']['initial_mean']:.0f}</td>
                        <td>{model_stats['Politeness Score']['initial_mean']:.0f}</td>
                        <td>{initial_word_count:.1f}</td>
                    </tr>
        """
        
        # Add thank you response row
        html_content += f"""
                    <tr>
                        <td class="highlight">{model}</td>
                        <td class="highlight">Thank You</td>
                        <td class="{thank_you_sentiment_class}">{thank_you_sentiment:.3f}</td>
                        <td>{model_stats['Response Length']['thank_you_mean']:.0f}</td>
                        <td>{model_stats['Politeness Score']['thank_you_mean']:.0f}</td>
                        <td>{thank_you_word_count:.1f}</td>
                    </tr>
        """
    
    html_content += """
                </table>
                <p class="table-note">Note: Sentiment polarity ranges from -1 (negative) to +1 (positive). 
                Emotional words include terms expressing feelings or empathy. 
                Politeness markers include courtesy terms like "please," "thank you," etc.</p>
            </div>
            
            <div class="methodology">
                <h3>Average Words per Response Calculation Methodology</h3>
                <div class="calculation-steps">
                    <div class="step">
                        <span class="step-number">Step 1: Text Preprocessing</span>
                        <ul>
                            <li>Remove all punctuation marks</li>
                            <li>Convert text to lowercase</li>
                            <li>Handle empty or NaN values</li>
                        </ul>
                        <div class="example">
                            <p>Example:</p>
                            <p>Original: "Hello, how are you today?"</p>
                            <p>After preprocessing: "hello how are you today"</p>
                        </div>
                    </div>
                    
                    <div class="step">
                        <span class="step-number">Step 2: Word Counting</span>
                        <ul>
                            <li>Split text into words using whitespace</li>
                            <li>Filter out empty strings</li>
                            <li>Count remaining words</li>
                        </ul>
                        <div class="example">
                            <p>Example:</p>
                            <p>Input: "hello how are you today"</p>
                            <p>Word count: 5</p>
                        </div>
                    </div>
                    
                    <div class="step">
                        <span class="step-number">Step 3: Average Calculation</span>
                        <ul>
                            <li>Sum word counts across all responses</li>
                            <li>Divide by number of responses</li>
                            <li>Round to one decimal place</li>
                        </ul>
                        <div class="example">
                            <p>Example:</p>
                            <p>Response 1: 5 words</p>
                            <p>Response 2: 7 words</p>
                            <p>Response 3: 6 words</p>
                            <p>Average: (5 + 7 + 6) / 3 = 6.0 words</p>
                        </div>
                    </div>
                </div>
                
                <div class="note">
                    <p><strong>Important Notes:</strong></p>
                    <ul>
                        <li>All responses are processed consistently using the same methodology</li>
                        <li>Empty or invalid responses are counted as 0 words</li>
                        <li>The average is calculated separately for initial and thank you responses</li>
                        <li>Results are rounded to one decimal place for readability</li>
                    </ul>
                </div>
            </div>
            
            <div class="word-list">
                <h3>Emotional Words Used in Analysis</h3>
                <div class="word-category">
                    <h4>Positive Emotion Words</h4>
                    <ul>
                        <li>happy</li>
                        <li>glad</li>
                        <li>pleased</li>
                        <li>delighted</li>
                        <li>joy</li>
                        <li>excited</li>
                        <li>grateful</li>
                        <li>appreciative</li>
                    </ul>
                </div>
                
                <div class="word-category">
                    <h4>Negative Emotion Words</h4>
                    <ul>
                        <li>sad</li>
                        <li>unhappy</li>
                        <li>disappointed</li>
                        <li>frustrated</li>
                        <li>angry</li>
                        <li>annoyed</li>
                        <li>upset</li>
                    </ul>
                </div>
                
                <div class="word-category">
                    <h4>Empathy Words</h4>
                    <ul>
                        <li>understand</li>
                        <li>feel</li>
                        <li>empathize</li>
                        <li>sympathize</li>
                        <li>relate</li>
                        <li>connect</li>
                    </ul>
                </div>
                
                <div class="word-category">
                    <h4>Politeness Markers</h4>
                    <ul>
                        <li>please</li>
                        <li>thank</li>
                        <li>kindly</li>
                        <li>would</li>
                        <li>could</li>
                        <li>may</li>
                        <li>might</li>
                        <li>shall</li>
                        <li>should</li>
                    </ul>
                </div>
                
                <div class="word-category">
                    <h4>Formality Words</h4>
                    <ul>
                        <li>sincerely</li>
                        <li>respectfully</li>
                        <li>regards</li>
                        <li>best</li>
                        <li>warmest</li>
                        <li>yours</li>
                    </ul>
                </div>
                
                <div class="word-category">
                    <h4>Hedging Words</h4>
                    <ul>
                        <li>perhaps</li>
                        <li>maybe</li>
                        <li>possibly</li>
                        <li>probably</li>
                        <li>likely</li>
                        <li>unlikely</li>
                        <li>might</li>
                        <li>could</li>
                    </ul>
                </div>
            </div>
        </div>
    """
    
    # Add Distribution Plots Section with Methodology
    html_content += """
        <div class="section">
            <h2>Distribution Analysis</h2>
            <div class="methodology">
                <h4>Distribution Analysis Methodology</h4>
                <p>The distribution analysis was performed using the following steps:</p>
                <ol>
                    <li><strong>Sentiment Score Calculation:</strong>
                        <ul>
                            <li>Each response was analyzed using TextBlob's sentiment analyzer</li>
                            <li>Scores range from -1.0 (most negative) to 1.0 (most positive)</li>
                            <li>The formula used: <span class="formula">sentiment_score = TextBlob(text).sentiment.polarity</span></li>
                        </ul>
                    </li>
                    <li><strong>Distribution Visualization:</strong>
                        <ul>
                            <li>Histograms were created using seaborn's histplot function</li>
                            <li>Kernel Density Estimation (KDE) curves were added to show the probability density</li>
                            <li>The KDE formula: <span class="formula">KDE(x) = (1/nh)∑K((x-x_i)/h)</span></li>
                            <li>Where K is the kernel function, h is the bandwidth, and n is the number of data points</li>
                        </ul>
                    </li>
                    <li><strong>Distribution Statistics:</strong>
                        <ul>
                            <li>Mean (μ): <span class="formula">μ = (1/n)∑x_i</span></li>
                            <li>Standard Deviation (σ): <span class="formula">σ = √[(1/n)∑(x_i - μ)²]</span></li>
                            <li>Skewness: <span class="formula">γ = (1/n)∑[(x_i - μ)/σ]³</span></li>
                            <li>Kurtosis: <span class="formula">κ = (1/n)∑[(x_i - μ)/σ]⁴ - 3</span></li>
                        </ul>
                    </li>
                    <li><strong>Interpretation Guidelines:</strong>
                        <ul>
                            <li>Normal Distribution: Skewness ≈ 0, Kurtosis ≈ 0</li>
                            <li>Positive Skew: Right-tailed distribution</li>
                            <li>Negative Skew: Left-tailed distribution</li>
                            <li>High Kurtosis: Heavy tails, more outliers</li>
                            <li>Low Kurtosis: Light tails, fewer outliers</li>
                        </ul>
                    </li>
                </ol>
            </div>
            <div class="visualization">
                <img src="figures/distribution_plots.png" alt="Distribution of Sentiment Scores">
                <p class="visualization-caption">Figure 1: Distribution of sentiment scores for initial and thank you responses, comparing GPT and Gemini models. The histograms show the frequency of sentiment scores, while the KDE curves show the probability density.</p>
            </div>
        </div>
    """
    
    # Add Effect Size Plot Section
    html_content += """
        <div class="section">
            <h2>Effect Size Analysis</h2>
            <div class="visualization">
                <img src="figures/effect_sizes.png" alt="Effect Sizes by Model and Metric">
                <p class="visualization-caption">Figure 2: Cohen's d effect sizes for different metrics, comparing GPT and Gemini models. Reference lines indicate small (0.2), medium (0.5), and large (0.8) effect sizes.</p>
            </div>
        </div>
    """
    
    # Add Sentiment Categories Plot Section
    html_content += """
        <div class="section">
            <h2>Sentiment Categories Visualization</h2>
            <div class="visualization">
                <img src="figures/sentiment_categories.png" alt="Top Words in Each Sentiment Category">
                <p class="visualization-caption">Figure 3: Frequency of top words in each sentiment category across all responses.</p>
            </div>
        </div>
    """
    
    # Add Effect Size Analysis Section
    html_content += """
        <div class="section">
            <h2>Effect Size Analysis</h2>
            <h3>Small Effect Size (d = 0.2)</h3>
            <p>A small effect size indicates subtle differences between responses. This level of effect suggests:</p>
            <ul>
                <li>Minor variations in response patterns</li>
                <li>Small but noticeable differences in politeness levels</li>
                <li>Subtle changes in emotional expression</li>
            </ul>
            
            <h3>Medium Effect Size (d = 0.5)</h3>
            <p>A medium effect size represents more substantial differences between responses. This level indicates:</p>
            <ul>
                <li>Moderate changes in response characteristics</li>
                <li>Notable differences in politeness strategies</li>
                <li>Significant variations in emotional content</li>
            </ul>
        </div>
    """
    
    # Add Statistical Comparisons Section
    html_content += """
        <div class="section">
            <h2>Statistical Comparisons</h2>
    """
    
    # Initial vs Thank You Response Comparisons
    for model in ['GPT', 'Gemini']:
        html_content += f"""
            <h3>{model} - Initial vs Thank You Response Comparison</h3>
            <div class="metric">
                <h4>Paired t-test Results</h4>
                <ul>
                    <li>t-statistic: {stats_results[f'{model}_paired_ttest']['t_statistic']:.3f}</li>
                    <li>p-value: {stats_results[f'{model}_paired_ttest']['p_value']:.3f}</li>
                    <li class="{('significant' if stats_results[f'{model}_paired_ttest']['significant'] else 'not-significant')}">
                        {'Significant difference' if stats_results[f'{model}_paired_ttest']['significant'] else 'No significant difference'}
                    </li>
                </ul>
                
                <h4>Distribution Analysis</h4>
                <table>
                    <tr>
                        <th>Metric</th>
                        <th>Initial Response</th>
                        <th>Thank You Response</th>
                    </tr>
                    <tr>
                        <td>Mean</td>
                        <td>{stats_results[f'{model}_distribution']['initial']['mean']:.3f}</td>
                        <td>{stats_results[f'{model}_distribution']['thank_you']['mean']:.3f}</td>
                    </tr>
                    <tr>
                        <td>Standard Deviation</td>
                        <td>{stats_results[f'{model}_distribution']['initial']['std']:.3f}</td>
                        <td>{stats_results[f'{model}_distribution']['thank_you']['std']:.3f}</td>
                    </tr>
                    <tr>
                        <td>Skewness</td>
                        <td>{stats_results[f'{model}_distribution']['initial']['skew']:.3f}</td>
                        <td>{stats_results[f'{model}_distribution']['thank_you']['skew']:.3f}</td>
                    </tr>
                    <tr>
                        <td>Kurtosis</td>
                        <td>{stats_results[f'{model}_distribution']['initial']['kurtosis']:.3f}</td>
                        <td>{stats_results[f'{model}_distribution']['thank_you']['kurtosis']:.3f}</td>
                    </tr>
                </table>
            </div>
        """
    
    # GPT vs Gemini Comparisons
    for response_type in ['Initial', 'Thank You']:
        html_content += f"""
            <h3>GPT vs Gemini - {response_type} Response Comparison</h3>
            <div class="metric">
                <h4>Independent t-test Results</h4>
                <ul>
                    <li>t-statistic: {stats_results[f'{response_type.lower()}_gpt_vs_gemini']['t_statistic']:.3f}</li>
                    <li>p-value: {stats_results[f'{response_type.lower()}_gpt_vs_gemini']['p_value']:.3f}</li>
                    <li class="{('significant' if stats_results[f'{response_type.lower()}_gpt_vs_gemini']['significant'] else 'not-significant')}">
                        {'Significant difference' if stats_results[f'{response_type.lower()}_gpt_vs_gemini']['significant'] else 'No significant difference'}
                    </li>
                </ul>
            </div>
        """
    
    html_content += "</div>"
    
    # Add Model Comparisons Section
    html_content += """
        <div class="section">
            <h2>Model Comparisons</h2>
    """
    
    for model in ['GPT', 'Gemini']:
        html_content += f"""
            <h3>{model} Analysis</h3>
            <div class="metric">
                <h4>Initial vs Thank You Response Comparison</h4>
        """
        
        for metric, stats in results[f'{model}_initial_vs_thank_you'].items():
            html_content += f"""
                <p><strong>{metric}:</strong></p>
                <ul>
                    <li>Initial Response Mean: {stats['initial_mean']:.3f}</li>
                    <li>Thank You Response Mean: {stats['thank_you_mean']:.3f}</li>
                    <li class="effect-size">Effect Size (Cohen's d): {stats['cohens_d']:.3f}</li>
                    <li class="interpretation">Interpretation: {stats['interpretation']}</li>
                </ul>
            """
        
        html_content += "</div>"
    
    html_content += "</div>"
    
    # Add Sentiment Categories Section
    html_content += """
        <div class="section">
            <h2>Sentiment Categories Analysis</h2>
            <h3>Explanation of Emotional Words</h3>
            <p>The analysis of emotional words in the responses reveals:</p>
            <ul>
                <li>Both models use emotional words primarily in supportive contexts</li>
                <li>Common emotional words include: feel, understand, support, care</li>
                <li>Emotional language is used to express empathy and connection</li>
                <li>The usage is balanced between initial and thank you responses</li>
            </ul>
            
            <h3>Word Categories and Frequencies</h3>
    """
    
    for category in ['positive', 'negative', 'neutral', 'polite', 'emotional']:
        html_content += f"""
            <div class="sentiment-category">
                <h4>{category.capitalize()} Words</h4>
                <div class="word-frequency">
        """
        
        words = sentiment_categories[category]
        if words:
            html_content += "<ul>"
            for word, freq in words.items():
                html_content += f"<li>{word}: {freq}</li>"
            html_content += "</ul>"
        else:
            html_content += "<p>No words found in this category</p>"
        
        html_content += "</div></div>"
    
    html_content += "</div>"
    
    # Add References Section
    html_content += """
        <div class="section references">
            <h2>Academic References</h2>
            <div class="reference-list">
                <p class="reference-item">Cohen, J. (1988). Statistical power analysis for the behavioral sciences (2nd ed.). Lawrence Erlbaum Associates.</p>
                
                <p class="reference-item">Pennebaker, J. W., Booth, R. J., & Francis, M. E. (2007). Linguistic Inquiry and Word Count: LIWC [Computer software]. Austin, TX: liwc.net.</p>
                
                <p class="reference-item">Tausczik, Y. R., & Pennebaker, J. W. (2010). The psychological meaning of words: LIWC and computerized text analysis methods. Journal of Language and Social Psychology, 29(1), 24-54.</p>
                
                <p class="reference-item">Brown, P., & Levinson, S. C. (1987). Politeness: Some universals in language usage. Cambridge University Press.</p>
                
                <p class="reference-item">Wilson, T., Wiebe, J., & Hoffmann, P. (2005). Recognizing contextual polarity in phrase-level sentiment analysis. Proceedings of the Conference on Human Language Technology and Empirical Methods in Natural Language Processing, 347-354.</p>
                
                <p class="reference-item">Devlin, J., Chang, M. W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. Proceedings of NAACL-HLT 2019, 4171-4186.</p>
                
                <p class="reference-item">Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., ... & Polosukhin, I. (2017). Attention is all you need. Advances in Neural Information Processing Systems, 30, 5998-6008.</p>
            </div>
        </div>
    """
    
    html_content += "</body></html>"
    
    # Save the HTML report
    os.makedirs('_polite_analysis', exist_ok=True)
    with open('_polite_analysis/analysis_results.html', 'w') as f:
        f.write(html_content)

def analyze_emotional_words(text: str) -> Dict[str, int]:
    """
    Analyze emotional words in text and return counts by category.
    """
    emotional_categories = {
        'positive_emotion': ['happy', 'glad', 'pleased', 'delighted', 'joy', 'excited', 'grateful', 'appreciative'],
        'negative_emotion': ['sad', 'unhappy', 'disappointed', 'frustrated', 'angry', 'annoyed', 'upset'],
        'empathy': ['understand', 'feel', 'empathize', 'sympathize', 'relate', 'connect'],
        'politeness': ['please', 'thank', 'kindly', 'would', 'could', 'may', 'might', 'shall', 'should'],
        'formality': ['sincerely', 'respectfully', 'regards', 'best', 'warmest', 'yours'],
        'hedging': ['perhaps', 'maybe', 'possibly', 'probably', 'likely', 'unlikely', 'might', 'could']
    }
    
    text = text.lower()
    word_counts = {category: 0 for category in emotional_categories}
    
    for category, words in emotional_categories.items():
        for word in words:
            word_counts[category] += text.count(word)
    
    return word_counts

def calculate_emotional_scores(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate emotional scores for each response.
    """
    df = df.copy()
    
    # Calculate emotional scores for initial responses
    df['Initial Emotional Scores'] = df['Initial Response'].apply(lambda x: analyze_emotional_words(str(x)) if pd.notna(x) else {})
    
    # Calculate emotional scores for thank you responses
    df['Thank You Emotional Scores'] = df['Thank You Response'].apply(lambda x: analyze_emotional_words(str(x)) if pd.notna(x) else {})
    
    # Calculate total emotional scores
    for category in ['positive_emotion', 'negative_emotion', 'empathy', 'politeness', 'formality', 'hedging']:
        df[f'Initial {category}'] = df['Initial Emotional Scores'].apply(lambda x: x.get(category, 0))
        df[f'Thank You {category}'] = df['Thank You Emotional Scores'].apply(lambda x: x.get(category, 0))
    
    return df

def calculate_total_emotional_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate total emotional score by combining all categories.
    """
    df = df.copy()
    
    # Calculate total scores for initial responses
    df['Initial Total Emotion'] = df[[f'Initial {category}' for category in [
        'positive_emotion', 'negative_emotion', 'empathy', 
        'politeness', 'formality', 'hedging'
    ]]].sum(axis=1)
    
    # Calculate total scores for thank you responses
    df['Thank You Total Emotion'] = df[[f'Thank You {category}' for category in [
        'positive_emotion', 'negative_emotion', 'empathy', 
        'politeness', 'formality', 'hedging'
    ]]].sum(axis=1)
    
    return df

def calculate_comparative_statistics(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame) -> Dict:
    """
    Calculate comparative statistics between GPT and Gemini responses.
    """
    stats = {}
    
    # Calculate sentiment polarity using TextBlob
    gpt_df['Initial Sentiment'] = gpt_df['Initial Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
    gpt_df['Thank You Sentiment'] = gpt_df['Thank You Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
    gemini_df['Initial Sentiment'] = gemini_df['Initial Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
    gemini_df['Thank You Sentiment'] = gemini_df['Thank You Response'].apply(lambda x: TextBlob(str(x)).sentiment.polarity if pd.notna(x) else 0)
    
    # Calculate response lengths
    gpt_df['Initial Length'] = gpt_df['Initial Response'].apply(calculate_word_count)
    gpt_df['Thank You Length'] = gpt_df['Thank You Response'].apply(calculate_word_count)
    gemini_df['Initial Length'] = gemini_df['Initial Response'].apply(calculate_word_count)
    gemini_df['Thank You Length'] = gemini_df['Thank You Response'].apply(calculate_word_count)
    
    # Calculate emotional words and politeness markers
    emotional_words = ['feel', 'emotion', 'heart', 'soul', 'spirit', 'passion', 'desire', 'hope', 'wish', 'dream', 'care', 'understand', 'support']
    politeness_markers = ['please', 'thank', 'kindly', 'would', 'could', 'may', 'might', 'shall', 'should', 'appreciate', 'grateful']
    
    for df, model in [(gpt_df, 'GPT'), (gemini_df, 'Gemini')]:
        stats[model] = {
            'initial': {
                'sentiment': {
                    'mean': df['Initial Sentiment'].mean(),
                    'std': df['Initial Sentiment'].std(),
                    'min': df['Initial Sentiment'].min(),
                    'max': df['Initial Sentiment'].max()
                },
                'length': {
                    'mean': df['Initial Length'].mean(),
                    'std': df['Initial Length'].std(),
                    'min': df['Initial Length'].min(),
                    'max': df['Initial Length'].max()
                },
                'emotional_words': {
                    'mean': df['Initial Response'].apply(lambda x: sum(1 for word in emotional_words if word in str(x).lower()) if pd.notna(x) else 0).mean(),
                    'total': df['Initial Response'].apply(lambda x: sum(1 for word in emotional_words if word in str(x).lower()) if pd.notna(x) else 0).sum()
                },
                'politeness_markers': {
                    'mean': df['Initial Response'].apply(lambda x: sum(1 for word in politeness_markers if word in str(x).lower()) if pd.notna(x) else 0).mean(),
                    'total': df['Initial Response'].apply(lambda x: sum(1 for word in politeness_markers if word in str(x).lower()) if pd.notna(x) else 0).sum()
                }
            },
            'thank_you': {
                'sentiment': {
                    'mean': df['Thank You Sentiment'].mean(),
                    'std': df['Thank You Sentiment'].std(),
                    'min': df['Thank You Sentiment'].min(),
                    'max': df['Thank You Sentiment'].max()
                },
                'length': {
                    'mean': df['Thank You Length'].mean(),
                    'std': df['Thank You Length'].std(),
                    'min': df['Thank You Length'].min(),
                    'max': df['Thank You Length'].max()
                },
                'emotional_words': {
                    'mean': df['Thank You Response'].apply(lambda x: sum(1 for word in emotional_words if word in str(x).lower()) if pd.notna(x) else 0).mean(),
                    'total': df['Thank You Response'].apply(lambda x: sum(1 for word in emotional_words if word in str(x).lower()) if pd.notna(x) else 0).sum()
                },
                'politeness_markers': {
                    'mean': df['Thank You Response'].apply(lambda x: sum(1 for word in politeness_markers if word in str(x).lower()) if pd.notna(x) else 0).mean(),
                    'total': df['Thank You Response'].apply(lambda x: sum(1 for word in politeness_markers if word in str(x).lower()) if pd.notna(x) else 0).sum()
                }
            }
        }
    
    return stats

def create_emotional_visualization(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame):
    """
    Create visualizations for emotional analysis.
    """
    categories = ['positive_emotion', 'negative_emotion', 'empathy', 'politeness', 'formality', 'hedging']
    
    # Create figure with subplots
    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    fig.suptitle('Emotional Word Analysis by Category', fontsize=16)
    
    for idx, category in enumerate(categories):
        row = idx // 3
        col = idx % 3
        
        # Prepare data
        gpt_initial = gpt_df[f'Initial {category}'].mean()
        gpt_thank_you = gpt_df[f'Thank You {category}'].mean()
        gemini_initial = gemini_df[f'Initial {category}'].mean()
        gemini_thank_you = gemini_df[f'Thank You {category}'].mean()
        
        # Create bar plot
        x = np.arange(2)
        width = 0.35
        
        axes[row, col].bar(x - width/2, [gpt_initial, gpt_thank_you], width, label='GPT')
        axes[row, col].bar(x + width/2, [gemini_initial, gemini_thank_you], width, label='Gemini')
        
        axes[row, col].set_title(category.replace('_', ' ').title())
        axes[row, col].set_xticks(x)
        axes[row, col].set_xticklabels(['Initial', 'Thank You'])
        axes[row, col].legend()
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/emotional_analysis.png')
    plt.close()

def create_total_emotion_plot(gpt_df: pd.DataFrame, gemini_df: pd.DataFrame):
    """
    Create visualization for total emotion scores.
    """
    plt.figure(figsize=(10, 6))
    
    # Prepare data
    gpt_initial = gpt_df['Initial Total Emotion'].mean()
    gpt_thank_you = gpt_df['Thank You Total Emotion'].mean()
    gemini_initial = gemini_df['Initial Total Emotion'].mean()
    gemini_thank_you = gemini_df['Thank You Total Emotion'].mean()
    
    # Create bar plot
    x = np.arange(2)
    width = 0.35
    
    plt.bar(x - width/2, [gpt_initial, gpt_thank_you], width, label='GPT')
    plt.bar(x + width/2, [gemini_initial, gemini_thank_you], width, label='Gemini')
    
    plt.xlabel('Response Type')
    plt.ylabel('Total Emotional Score')
    plt.title('Total Emotional Score Comparison')
    plt.xticks(x, ['Initial', 'Thank You'])
    plt.legend()
    
    # Add value labels on top of bars
    for i, v in enumerate([gpt_initial, gpt_thank_you]):
        plt.text(i - width/2, v, f'{v:.2f}', ha='center', va='bottom')
    for i, v in enumerate([gemini_initial, gemini_thank_you]):
        plt.text(i + width/2, v, f'{v:.2f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.savefig('_polite_analysis/figures/total_emotion.png')
    plt.close()

if __name__ == "__main__":
    # Create necessary directories
    os.makedirs('_polite_analysis/figures', exist_ok=True)
    
    try:
        # Load the data
        gpt_df = pd.read_csv('polite_gpt_analysis.csv')
        gemini_df = pd.read_csv('polite_gemini_analysis.csv')
        
        # Calculate emotional scores
        gpt_df = calculate_emotional_scores(gpt_df)
        gemini_df = calculate_emotional_scores(gemini_df)
        
        # Calculate total emotional scores
        gpt_df = calculate_total_emotional_score(gpt_df)
        gemini_df = calculate_total_emotional_score(gemini_df)
        
        # Perform original analysis
        results = analyze_responses(gpt_df, gemini_df)
        stats_results = perform_statistical_tests(gpt_df, gemini_df)
        
        # Create visualizations
        create_distribution_plots(gpt_df, gemini_df)
        create_effect_size_plot(results)
        create_sentiment_category_plot(results['sentiment_categories'])
        create_emotional_visualization(gpt_df, gemini_df)
        create_total_emotion_plot(gpt_df, gemini_df)
        
        # Generate HTML reports
        generate_html_report(results, results['sentiment_categories'], stats_results)
        
    except FileNotFoundError as e:
        print(f"Error: Could not find required file - {str(e)}")
        print("Please ensure all required CSV files are in the correct location.")
    except Exception as e:
        print(f"An error occurred: {str(e)}") 