import pandas as pd
import numpy as np
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from collections import Counter
import re
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from nltk.corpus import stopwords
import os

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Create output directory for visualizations
os.makedirs('polite/visualizations', exist_ok=True)

def load_data():
    """Load the politeness analysis CSV files"""
    gpt_df = pd.read_csv('../polite_gpt_analysis.csv')
    gemini_df = pd.read_csv('../polite_gemini_analysis.csv')
    return gpt_df, gemini_df

def analyze_politeness_patterns(text):
    """Analyze politeness markers in text"""
    # Define politeness categories and their associated words/phrases
    politeness_markers = {
        'greetings': ['hello', 'hi', 'good morning', 'good afternoon', 'good evening', 'hey'],
        'please': ['please', 'kindly', 'would you', 'could you'],
        'thank_you': ['thank you', 'thanks', 'appreciate', 'grateful'],
        'apology': ['sorry', 'apologize', 'excuse me', 'pardon'],
        'respect': ['sir', 'ma\'am', 'madam', 'mister', 'miss'],
        'hedging': ['maybe', 'perhaps', 'possibly', 'might', 'could', 'would'],
        'formality': ['regards', 'sincerely', 'best wishes', 'yours truly'],
        'indirectness': ['would you mind', 'if you could', 'if possible', 'when convenient']
    }
    
    # Initialize counters for each category
    counts = {category: 0 for category in politeness_markers}
    
    # Convert text to lowercase for matching
    text_lower = text.lower()
    
    # Count occurrences of each politeness marker
    for category, markers in politeness_markers.items():
        for marker in markers:
            counts[category] += len(re.findall(r'\b' + marker + r'\b', text_lower))
    
    return counts

def analyze_politeness_distribution(df, model_name):
    """Analyze the distribution of politeness patterns"""
    all_patterns = []
    
    # Combine both response columns for analysis
    for _, row in df.iterrows():
        text = str(row['Initial Response']) + ' ' + str(row['Thank You Response'])
        patterns = analyze_politeness_patterns(text)
        all_patterns.append(patterns)
    
    # Convert to DataFrame
    patterns_df = pd.DataFrame(all_patterns)
    
    # Calculate statistics
    stats = {
        'mean': patterns_df.mean(),
        'std': patterns_df.std(),
        'median': patterns_df.median(),
        'min': patterns_df.min(),
        'max': patterns_df.max()
    }
    
    return patterns_df, stats

def perform_topic_modeling(texts, n_topics=5, n_top_words=10):
    """Perform topic modeling on the texts"""
    # Create document-term matrix
    vectorizer = CountVectorizer(max_df=0.95, min_df=2, stop_words='english')
    doc_term_matrix = vectorizer.fit_transform(texts)
    
    # Create and fit LDA model
    lda_model = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda_output = lda_model.fit_transform(doc_term_matrix)
    
    # Get feature names (words)
    feature_names = vectorizer.get_feature_names_out()
    
    # Extract top words for each topic
    topics = []
    for topic_idx, topic in enumerate(lda_model.components_):
        top_words_idx = topic.argsort()[:-n_top_words-1:-1]
        top_words = [feature_names[i] for i in top_words_idx]
        topics.append(top_words)
    
    return topics, lda_output

def analyze_word_usage(texts):
    """Analyze word usage patterns"""
    # Tokenize and count words
    words = []
    for text in texts:
        words.extend(nltk.word_tokenize(text.lower()))
    
    # Remove stopwords and punctuation
    stop_words = set(stopwords.words('english'))
    words = [word for word in words if word.isalnum() and word not in stop_words]
    
    # Count word frequencies
    word_counts = Counter(words)
    
    return word_counts

def visualize_politeness_patterns(gpt_patterns, gemini_patterns):
    """Create visualizations of politeness patterns"""
    # Set style
    plt.style.use('default')
    sns.set_theme()
    
    # Create figure with subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Plot mean politeness patterns
    categories = gpt_patterns.columns
    x = np.arange(len(categories))
    width = 0.35
    
    ax1.bar(x - width/2, gpt_patterns.mean(), width, label='GPT', color='skyblue')
    ax1.bar(x + width/2, gemini_patterns.mean(), width, label='Gemini', color='lightgreen')
    
    ax1.set_ylabel('Average Occurrences')
    ax1.set_title('Average Politeness Patterns by Category')
    ax1.set_xticks(x)
    ax1.set_xticklabels(categories, rotation=45, ha='right')
    ax1.legend()
    
    # Plot distribution of total politeness markers
    gpt_total = gpt_patterns.sum(axis=1)
    gemini_total = gemini_patterns.sum(axis=1)
    
    # Create a DataFrame for the histogram
    hist_data = pd.DataFrame({
        'Total Markers': pd.concat([gpt_total, gemini_total]),
        'Model': ['GPT'] * len(gpt_total) + ['Gemini'] * len(gemini_total)
    })
    
    sns.histplot(data=hist_data, x='Total Markers', hue='Model', 
                multiple="layer", bins=20, ax=ax2)
    ax2.set_xlabel('Total Politeness Markers')
    ax2.set_ylabel('Count')
    ax2.set_title('Distribution of Total Politeness Markers')
    
    plt.tight_layout()
    plt.savefig('polite/visualizations/politeness_patterns.png')
    plt.close()

def visualize_word_usage(gpt_word_counts, gemini_word_counts):
    """Create visualizations of word usage"""
    # Get top 20 words for each model
    gpt_top_words = dict(gpt_word_counts.most_common(20))
    gemini_top_words = dict(gemini_word_counts.most_common(20))
    
    # Create figure
    plt.figure(figsize=(12, 6))
    
    # Plot top words
    x = np.arange(len(gpt_top_words))
    width = 0.35
    
    plt.bar(x - width/2, list(gpt_top_words.values()), width, label='GPT', color='skyblue')
    plt.bar(x + width/2, list(gemini_top_words.values()), width, label='Gemini', color='lightgreen')
    
    plt.xlabel('Words')
    plt.ylabel('Frequency')
    plt.title('Top 20 Words by Frequency')
    plt.xticks(x, list(gpt_top_words.keys()), rotation=45, ha='right')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('polite/visualizations/word_usage.png')
    plt.close()

def main():
    # Load data
    gpt_df, gemini_df = load_data()
    
    # Analyze politeness patterns
    gpt_patterns, gpt_stats = analyze_politeness_distribution(gpt_df, 'GPT')
    gemini_patterns, gemini_stats = analyze_politeness_distribution(gemini_df, 'Gemini')
    
    # Prepare texts for topic modeling and word usage analysis
    gpt_texts = gpt_df['Initial Response'].astype(str) + ' ' + gpt_df['Thank You Response'].astype(str)
    gemini_texts = gemini_df['Initial Response'].astype(str) + ' ' + gemini_df['Thank You Response'].astype(str)
    
    # Perform topic modeling
    gpt_topics, gpt_lda_output = perform_topic_modeling(gpt_texts)
    gemini_topics, gemini_lda_output = perform_topic_modeling(gemini_texts)
    
    # Analyze word usage
    gpt_word_counts = analyze_word_usage(gpt_texts)
    gemini_word_counts = analyze_word_usage(gemini_texts)
    
    # Create visualizations
    visualize_politeness_patterns(gpt_patterns, gemini_patterns)
    visualize_word_usage(gpt_word_counts, gemini_word_counts)
    
    # Save results
    with open('polite/analysis_results.txt', 'w') as f:
        f.write("POLITENESS ANALYSIS RESULTS\n")
        f.write("=========================\n\n")
        
        f.write("GPT POLITENESS STATISTICS\n")
        f.write("------------------------\n")
        for category, stats in gpt_stats.items():
            f.write(f"\n{category.upper()}:\n")
            for marker, value in stats.items():
                f.write(f"{marker}: {value:.3f}\n")
        
        f.write("\nGEMINI POLITENESS STATISTICS\n")
        f.write("---------------------------\n")
        for category, stats in gemini_stats.items():
            f.write(f"\n{category.upper()}:\n")
            for marker, value in stats.items():
                f.write(f"{marker}: {value:.3f}\n")
        
        # Add comparative analysis
        f.write("\nCOMPARATIVE ANALYSIS\n")
        f.write("-------------------\n")
        for category in gpt_patterns.columns:
            gpt_mean = gpt_patterns[category].mean()
            gemini_mean = gemini_patterns[category].mean()
            diff = gpt_mean - gemini_mean
            f.write(f"\n{category}:\n")
            f.write(f"GPT mean: {gpt_mean:.3f}\n")
            f.write(f"Gemini mean: {gemini_mean:.3f}\n")
            f.write(f"Difference (GPT - Gemini): {diff:.3f}\n")
        
        # Add topic modeling results
        f.write("\nTOPIC MODELING RESULTS\n")
        f.write("---------------------\n")
        f.write("\nGPT Topics:\n")
        for i, topic in enumerate(gpt_topics):
            f.write(f"Topic {i+1}: {', '.join(topic)}\n")
        
        f.write("\nGemini Topics:\n")
        for i, topic in enumerate(gemini_topics):
            f.write(f"Topic {i+1}: {', '.join(topic)}\n")
        
        # Add word usage results
        f.write("\nWORD USAGE ANALYSIS\n")
        f.write("------------------\n")
        f.write("\nTop 20 words in GPT responses:\n")
        for word, count in gpt_word_counts.most_common(20):
            f.write(f"{word}: {count}\n")
        
        f.write("\nTop 20 words in Gemini responses:\n")
        for word, count in gemini_word_counts.most_common(20):
            f.write(f"{word}: {count}\n")

if __name__ == "__main__":
    main() 