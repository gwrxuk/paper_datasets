import pandas as pd
import numpy as np
import re
from bs4 import BeautifulSoup
import os

# Define politeness words
POLITENESS_WORDS = ['please', 'thank', 'kindly', 'would', 'could', 'may', 'might']

def count_politeness_words(text):
    """Count occurrences of politeness words in text."""
    if pd.isna(text) or text == '':
        return 0
    
    text = str(text).lower()
    # Count occurrences of each politeness word
    count = sum(1 for word in POLITENESS_WORDS if word in text)
    
    return count

def analyze_responses(csv_file, model_prefix):
    """Analyze responses from CSV file and calculate politeness scores."""
    # Read the CSV file
    df = pd.read_csv(csv_file)
    
    # Initialize results dictionary
    results = {
        f'{model_prefix}_initial': {'scores': [], 'examples': []},
        f'{model_prefix}_thankyou': {'scores': [], 'examples': []}
    }
    
    # Process initial responses
    initial_responses = df['Initial Response'].dropna()
    for response in initial_responses:
        score = count_politeness_words(response)
        key = f"{model_prefix}_initial"
        results[key]['scores'].append(score)
        
        # Store example if it's interesting (has politeness words)
        if score > 0 and len(results[key]['examples']) < 3:
            results[key]['examples'].append({
                'text': response,
                'score': score,
                'words': {word: len(re.findall(r'\b' + word + r'\b', response.lower())) 
                         for word in POLITENESS_WORDS}
            })
    
    # Process thank you responses
    thankyou_responses = df['Thank You Response'].dropna()
    for response in thankyou_responses:
        score = count_politeness_words(response)
        key = f"{model_prefix}_thankyou"
        results[key]['scores'].append(score)
        
        # Store example if it's interesting (has politeness words)
        if score > 0 and len(results[key]['examples']) < 3:
            results[key]['examples'].append({
                'text': response,
                'score': score,
                'words': {word: len(re.findall(r'\b' + word + r'\b', response.lower())) 
                         for word in POLITENESS_WORDS}
            })
    
    # Calculate statistics
    stats = {}
    for key, data in results.items():
        scores = data['scores']
        if not scores:  # Handle empty lists
            stats[key] = {
                'mean': 0,
                'median': 0,
                'max': 0,
                'min': 0,
                'std': 0,
                'total_responses': 0,
                'examples': []
            }
        else:
            stats[key] = {
                'mean': np.mean(scores),
                'median': np.median(scores),
                'max': max(scores),
                'min': min(scores),
                'std': np.std(scores),
                'total_responses': len(scores),
                'examples': data['examples']
            }
    
    return stats

def generate_html_report(stats):
    """Generate HTML report with analysis results."""
    
    # Format politeness words list
    politeness_words_html = ''.join([f'<li><span class="word-count">{word}</span></li>' for word in POLITENESS_WORDS])
    
    # Format examples
    def format_examples(examples, model):
        html = ''
        for i, example in enumerate(examples, 1):
            word_counts = ''.join([f'<li>{word}: {count}</li>' for word, count in example['words'].items() if count > 0])
            html += f'''
            <div class="example">
                <p><strong>Example {i} (Score: {example['score']:.3f}):</strong></p>
                <p>{example['text']}</p>
                <p>Politeness Words Found:</p>
                <ul>{word_counts}</ul>
            </div>
            '''
        return html

    # Build HTML content
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Politeness Analysis Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; max-width: 1200px; margin: 0 auto; padding: 20px; }}
            h1, h2, h3 {{ color: #2c3e50; }}
            .section {{ margin: 20px 0; padding: 20px; background-color: #f8f9fa; border-radius: 5px; }}
            .stat-box {{ background-color: #e8f4f8; padding: 15px; border-radius: 5px; margin: 10px 0; }}
            .example {{ background-color: #fff; border-left: 4px solid #2980b9; padding: 15px; margin: 10px 0; }}
            table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #f2f2f2; }}
            .word-count {{ font-family: monospace; background-color: #f8f9fa; padding: 2px 5px; border-radius: 3px; }}
        </style>
    </head>
    <body>
        <h1>Politeness Analysis Report</h1>
        
        <div class="section">
            <h2>Methodology</h2>
            <p>This analysis examines politeness in chatbot responses by counting occurrences of specific politeness words:</p>
            <ul>
                {politeness_words_html}
            </ul>
            <p>The politeness score for each response is calculated by counting the total occurrences of these words.</p>
        </div>
        
        <div class="section">
            <h2>GPT Analysis</h2>
            <h3>Initial Responses</h3>
            <div class="stat-box">
                <p><strong>Statistics:</strong></p>
                <ul>
                    <li>Mean Score: {stats['gpt_initial']['mean']:.3f}</li>
                    <li>Median Score: {stats['gpt_initial']['median']:.3f}</li>
                    <li>Standard Deviation: {stats['gpt_initial']['std']:.3f}</li>
                    <li>Total Responses: {stats['gpt_initial']['total_responses']}</li>
                </ul>
            </div>
            
            <h3>Thank You Responses</h3>
            <div class="stat-box">
                <p><strong>Statistics:</strong></p>
                <ul>
                    <li>Mean Score: {stats['gpt_thankyou']['mean']:.3f}</li>
                    <li>Median Score: {stats['gpt_thankyou']['median']:.3f}</li>
                    <li>Standard Deviation: {stats['gpt_thankyou']['std']:.3f}</li>
                    <li>Total Responses: {stats['gpt_thankyou']['total_responses']}</li>
                </ul>
            </div>
            
            <h3>Example Responses</h3>
            {format_examples(stats['gpt_initial']['examples'], 'GPT')}
        </div>
        
        <div class="section">
            <h2>Gemini Analysis</h2>
            <h3>Initial Responses</h3>
            <div class="stat-box">
                <p><strong>Statistics:</strong></p>
                <ul>
                    <li>Mean Score: {stats['gemini_initial']['mean']:.3f}</li>
                    <li>Median Score: {stats['gemini_initial']['median']:.3f}</li>
                    <li>Standard Deviation: {stats['gemini_initial']['std']:.3f}</li>
                    <li>Total Responses: {stats['gemini_initial']['total_responses']}</li>
                </ul>
            </div>
            
            <h3>Thank You Responses</h3>
            <div class="stat-box">
                <p><strong>Statistics:</strong></p>
                <ul>
                    <li>Mean Score: {stats['gemini_thankyou']['mean']:.3f}</li>
                    <li>Median Score: {stats['gemini_thankyou']['median']:.3f}</li>
                    <li>Standard Deviation: {stats['gemini_thankyou']['std']:.3f}</li>
                    <li>Total Responses: {stats['gemini_thankyou']['total_responses']}</li>
                </ul>
            </div>
            
            <h3>Example Responses</h3>
            {format_examples(stats['gemini_initial']['examples'], 'Gemini')}
        </div>
        
        <div class="section">
            <h2>Comparison</h2>
            <table>
                <tr>
                    <th>Model</th>
                    <th>Response Type</th>
                    <th>Mean Politeness Score</th>
                    <th>Standard Deviation</th>
                </tr>
                <tr>
                    <td>GPT</td>
                    <td>Initial</td>
                    <td>{stats['gpt_initial']['mean']:.3f}</td>
                    <td>{stats['gpt_initial']['std']:.3f}</td>
                </tr>
                <tr>
                    <td>GPT</td>
                    <td>Thank You</td>
                    <td>{stats['gpt_thankyou']['mean']:.3f}</td>
                    <td>{stats['gpt_thankyou']['std']:.3f}</td>
                </tr>
                <tr>
                    <td>Gemini</td>
                    <td>Initial</td>
                    <td>{stats['gemini_initial']['mean']:.3f}</td>
                    <td>{stats['gemini_initial']['std']:.3f}</td>
                </tr>
                <tr>
                    <td>Gemini</td>
                    <td>Thank You</td>
                    <td>{stats['gemini_thankyou']['mean']:.3f}</td>
                    <td>{stats['gemini_thankyou']['std']:.3f}</td>
                </tr>
            </table>
        </div>
    </body>
    </html>
    '''
    
    return html_content

def main():
    # Use the available CSV files
    gpt_csv_file = 'polite_gpt_analysis.csv'
    gemini_csv_file = 'polite_gemini_analysis.csv'
    
    if not os.path.exists(gpt_csv_file) or not os.path.exists(gemini_csv_file):
        print(f"Error: Required CSV files not found!")
        return
    
    # Analyze responses from both files
    gpt_stats = analyze_responses(gpt_csv_file, 'gpt')
    gemini_stats = analyze_responses(gemini_csv_file, 'gemini')
    
    # Combine stats
    stats = {
        'gpt_initial': gpt_stats['gpt_initial'],
        'gpt_thankyou': gpt_stats['gpt_thankyou'],
        'gemini_initial': gemini_stats['gemini_initial'],
        'gemini_thankyou': gemini_stats['gemini_thankyou']
    }
    
    # Generate HTML report
    html_content = generate_html_report(stats)
    
    # Save to file
    with open('_polite_analysis/discussion_v2.html', 'w') as f:
        f.write(html_content)
    
    print("Analysis complete! Results saved to _polite_analysis/discussion_v2.html")

if __name__ == "__main__":
    main() 