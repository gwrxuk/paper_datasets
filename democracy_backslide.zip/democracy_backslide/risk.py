# Democratic Backsliding Index Calculation (Updated May 2025 data)

# 1. Sentiment input
sentiment_score = 0.402
inverted_sentiment = 1 - sentiment_score  # = 0.598

# 2. Symbolic terms frequencies (counts from the report)
total_words = 1287363  # total word count in corpus
symbolic_counts = {
    "中共": 373,
    "綠共": 526,
    "迫害": 130,
    "恐懼": 31,
    "叛國": 7,
    "陰謀": 8,
    "滲透": 85
}
# Normalize counts to fraction of total words
symbolic_freq = sum(symbolic_counts.values()) / total_words  # ≈0.000901 (0.09%)
# Symbolic score S_t is average of inverted sentiment and symbolic term frequency
S_t = (inverted_sentiment + symbolic_freq) / 2

# 3. Ideological/Identity terms frequencies
cognitive_counts = {
    "自由": 471,
    "民主": 740,
    "國家": 533,
    "正義": 37,
    "安全": 429,
    "政治": 1280,
    "主權": 53,
    "台灣": 2668
}
cognitive_freq = sum(cognitive_counts.values()) / total_words  # ≈0.0048246 (0.48%)
# Cognitive score C_t is just the normalized frequency
C_t = cognitive_freq

# 4. Institutional terms frequencies
institutional_counts = {
    "黨": 686,
    "國民黨": 1017,
    "民進黨": 1555,
    "立委": 1112,
    "立法院": 298,
    "總統": 428,
    "法官": 61,
    "法院": 137,
    "政府": 740
}
institutional_freq = sum(institutional_counts.values()) / total_words  # ≈0.004687 (0.47%)
baseline = 0.01  # baseline 1% normalized frequency
excess = max(0, institutional_freq - baseline)  # only count excess above 1%
# Policy score P_t starts at 1.0 and increases by any excess over baseline
P_t = 1.0 + excess  # here, excess is 0 (below baseline), so P_t = 1.0

# 5. Overall backsliding index R_t
R_t = (S_t + C_t) * P_t

print(f"S_t = {S_t:.3f}", 
      f"C_t = {C_t:.3f}", 
      f"P_t = {P_t:.3f}", 
      f"R_t = {R_t:.3f}", sep="\n")
