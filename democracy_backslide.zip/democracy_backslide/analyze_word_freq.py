import os
import logging
from collections import Counter
import re

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def load_segmented_files(folder_path):
    """Load all segmented files from the specified folder."""
    logging.info("Loading segmented files...")
    all_words = []
    for filename in os.listdir(folder_path):
        if filename.endswith('_segmented.txt'):
            with open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:
                    words = content.split()
                    all_words.extend(words)
    return all_words

def analyze_word_frequencies(words, target_words):
    """Analyze frequencies of target words in the corpus."""
    logging.info("Analyzing word frequencies...")
    
    # Count all words for normalization
    total_words = len(words)
    word_counts = Counter(words)
    
    # Get frequencies for target words
    frequencies = {}
    for word in target_words:
        frequencies[word] = word_counts.get(word, 0)
    
    # Add total word count
    frequencies['__total_words__'] = total_words
    
    return frequencies

def generate_html_report(frequencies, symbolic_terms, cognitive_terms, policy_terms):
    """Generate an HTML report with the analysis results."""
    # Calculate statistics
    total_words = frequencies['__total_words__']
    unique_words = len(set(frequencies.keys()) - {'__total_words__'})
    file_count = len([f for f in os.listdir('segment') if f.endswith('_segmented.txt')])
    avg_words_per_file = total_words / file_count if file_count > 0 else 0

    html_content = f"""
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>詞頻分析報告</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                background-color: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }}
            h1, h2 {{
                color: #333;
                border-bottom: 2px solid #eee;
                padding-bottom: 10px;
            }}
            .stats {{
                background-color: #f8f9fa;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 15px;
            }}
            .stat-item {{
                background-color: #fff;
                padding: 15px;
                border-radius: 5px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                text-align: center;
            }}
            .stat-value {{
                font-size: 1.5em;
                font-weight: bold;
                color: #2c3e50;
            }}
            .stat-label {{
                color: #666;
                margin-top: 5px;
            }}
            .word-group {{
                margin-bottom: 30px;
            }}
            .word-list {{
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 10px;
            }}
            .word-item {{
                background-color: #fff;
                padding: 10px;
                border-radius: 5px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }}
            .word {{
                font-weight: bold;
                color: #2c3e50;
            }}
            .count {{
                color: #7f8c8d;
                font-size: 0.9em;
            }}
            .percentage {{
                color: #27ae60;
                font-size: 0.8em;
            }}
            .note {{
                font-size: 0.9em;
                color: #666;
                margin-top: 5px;
                text-align: center;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>詞頻分析報告</h1>
            
            <div class="stats">
                <h2>總體統計</h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-value">{file_count:,}</div>
                        <div class="stat-label">文件總數</div>
                        <div class="note">(segment 資料夾中的文件數)</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">{total_words:,}</div>
                        <div class="stat-label">總詞數</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">{unique_words:,}</div>
                        <div class="stat-label">不重複詞數</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">{avg_words_per_file:.1f}</div>
                        <div class="stat-label">平均每文件詞數</div>
                    </div>
                </div>
            </div>
            
            <div class="word-group">
                <h2>象徵性詞彙</h2>
                <div class="word-list">
    """

    # Add symbolic terms
    for word in symbolic_terms:
        count = frequencies[word]
        percentage = (count / total_words) * 100
        html_content += f"""
                    <div class="word-item">
                        <div class="word">{word}</div>
                        <div class="count">出現次數: {count:,}</div>
                        <div class="percentage">佔比: {percentage:.2f}%</div>
                    </div>
        """

    html_content += """
                </div>
            </div>
            
            <div class="word-group">
                <h2>認知性詞彙</h2>
                <div class="word-list">
    """

    # Add cognitive terms
    for word in cognitive_terms:
        count = frequencies[word]
        percentage = (count / total_words) * 100
        html_content += f"""
                    <div class="word-item">
                        <div class="word">{word}</div>
                        <div class="count">出現次數: {count:,}</div>
                        <div class="percentage">佔比: {percentage:.2f}%</div>
                    </div>
        """

    html_content += """
                </div>
            </div>
            
            <div class="word-group">
                <h2>政策/制度性詞彙</h2>
                <div class="word-list">
    """

    # Add policy terms
    for word in policy_terms:
        count = frequencies[word]
        percentage = (count / total_words) * 100
        html_content += f"""
                    <div class="word-item">
                        <div class="word">{word}</div>
                        <div class="count">出現次數: {count:,}</div>
                        <div class="percentage">佔比: {percentage:.2f}%</div>
                    </div>
        """

    html_content += """
                </div>
            </div>
        </div>
    </body>
    </html>
    """

    # Save HTML file
    with open('word_frequency_analysis.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    logging.info("HTML report generated: word_frequency_analysis.html")

def main():
    # Get current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    segment_folder = os.path.join(current_dir, "segment")
    
    # Define target words
    symbolic_terms = ['中共', '綠共', '迫害', '恐懼', '叛國', '陰謀', '滲透']
    cognitive_terms = ['自由', '民主', '國家', '正義', '安全', '政治', '主權', '台灣']
    policy_terms = ['黨', '國民黨', '民進黨', '立委', '立法院', '總統', '法官', '法院', '政府']
    
    # Combine all target words
    target_words = symbolic_terms + cognitive_terms + policy_terms
    
    # Load and analyze files
    words = load_segmented_files(segment_folder)
    frequencies = analyze_word_frequencies(words, target_words)
    
    # Generate HTML report
    generate_html_report(frequencies, symbolic_terms, cognitive_terms, policy_terms)
    
    # Print results in the required format
    print("\nword_freq = {")
    print("    # Symbolic words")
    for word in symbolic_terms:
        print(f"    '{word}': {frequencies[word]},")
    
    print("\n    # Cognitive (ideological) words")
    for word in cognitive_terms:
        print(f"    '{word}': {frequencies[word]},")
    
    print("\n    # Policy/institutional words")
    for word in policy_terms:
        print(f"    '{word}': {frequencies[word]},")
    
    print("\n    # For normalization")
    print(f"    '__total_words__': {frequencies['__total_words__']}  # Total token count in the corpus")
    print("}")
    
    print("\n# Define term groups")
    print("symbolic_terms =", symbolic_terms)
    print("cognitive_terms =", cognitive_terms)
    print("policy_terms =", policy_terms)

if __name__ == "__main__":
    main() 