import os
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def remove_files_with_character(folder_path, target_char="厂"):
    """
    Remove files from the specified folder that contain the target character.
    
    Args:
        folder_path (str): Path to the folder containing files to check
        target_char (str): Character to search for in file content
    """
    if not os.path.exists(folder_path):
        logging.error(f"Folder {folder_path} does not exist")
        return
    
    removed_count = 0
    total_files = 0
    
    for filename in os.listdir(folder_path):
        if not filename.endswith('_segmented.txt'):
            continue
            
        file_path = os.path.join(folder_path, filename)
        total_files += 1
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if target_char in content:
                os.remove(file_path)
                removed_count += 1
                logging.info(f"Removed {filename} (contains character '{target_char}')")
                
        except Exception as e:
            logging.error(f"Error processing {filename}: {str(e)}")
    
    logging.info(f"Processed {total_files} files")
    logging.info(f"Removed {removed_count} files containing character '{target_char}'")

if __name__ == "__main__":
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    segment_folder = os.path.join(current_dir, "segment")
    remove_files_with_character(segment_folder) 