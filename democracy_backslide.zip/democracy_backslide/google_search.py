import os
import json
import time
import pandas as pd
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

def setup_google_search():
    """Set up Google Custom Search API service."""
    # API credentials
    api_key = ""
    search_engine_id = ""
    
    try:
        service = build("customsearch", "v1", developerKey=api_key)
        return service, search_engine_id
    except Exception as e:
        print(f"Error setting up Google Search API: {e}")
        return None, None

def search_keyword(service, search_engine_id, keyword, max_results=1000):
    """Search for a keyword and return results."""
    all_results = []
    start_index = 1
    max_retries = 3
    retry_count = 0
    
    while len(all_results) < max_results and retry_count < max_retries:
        try:
            # Search with the current start index
            result = service.cse().list(
                q=keyword,
                cx=search_engine_id,
                start=start_index,
                num=10,  # Maximum results per request
                dateRestrict='m6'  # Limit to last 6 months
            ).execute()
            
            # Add results to our list
            if 'items' in result:
                for item in result['items']:
                    # Check for duplicates
                    if not any(r['link'] == item.get('link', '') for r in all_results):
                        all_results.append({
                            'keyword': keyword,
                            'title': item.get('title', ''),
                            'link': item.get('link', ''),
                            'description': item.get('snippet', '')
                        })
                print(f"Found {len(all_results)} unique results for '{keyword}' so far")
            
            # Check if we've reached the end of results
            if 'queries' in result and 'nextPage' in result['queries']:
                start_index = result['queries']['nextPage'][0]['startIndex']
                # Reset retry count on successful page
                retry_count = 0
            else:
                print(f"Warning: Only found {len(all_results)} results for '{keyword}'")
                break
                
            # Sleep to avoid rate limiting
            time.sleep(2)
            
        except HttpError as e:
            print(f"Error searching for '{keyword}': {e}")
            retry_count += 1
            if retry_count < max_retries:
                print(f"Retrying... (attempt {retry_count + 1} of {max_retries})")
                time.sleep(5)
                continue
            else:
                print(f"Max retries reached for '{keyword}'")
                break
        except Exception as e:
            print(f"Unexpected error for '{keyword}': {e}")
            retry_count += 1
            if retry_count < max_retries:
                print(f"Retrying... (attempt {retry_count + 1} of {max_retries})")
                time.sleep(5)
                continue
            else:
                print(f"Max retries reached for '{keyword}'")
                break
    
    # If we didn't get enough results, try with different search parameters
    if len(all_results) < max_results:
        print(f"Trying alternative search for '{keyword}'...")
        alternative_searches = [
            f"{keyword} site:tw",  # Taiwan sites
            f"{keyword} after:2023-01-01",  # Recent results
            f"{keyword} inurl:news",  # News sites
        ]
        
        for alt_search in alternative_searches:
            if len(all_results) >= max_results:
                break
                
            try:
                result = service.cse().list(
                    q=alt_search,
                    cx=search_engine_id,
                    start=1,
                    num=10
                ).execute()
                
                if 'items' in result:
                    for item in result['items']:
                        if len(all_results) >= max_results:
                            break
                        # Check for duplicates
                        if not any(r['link'] == item.get('link', '') for r in all_results):
                            all_results.append({
                                'keyword': keyword,
                                'title': item.get('title', ''),
                                'link': item.get('link', ''),
                                'description': item.get('snippet', '')
                            })
                    print(f"Found {len(all_results)} unique results for '{keyword}' with alternative search")
            except Exception as e:
                print(f"Error in alternative search for '{keyword}': {e}")
                continue
    
    print(f"Final count for '{keyword}': {len(all_results)} unique results")
    return all_results

def main():
    # Keywords to search
    keywords = [
        "綠共",
        "綠色恐怖",
        "司法 雙標",
        "大罷免",
        "東廠",
        "中配 亞亞",
        "陸配 亞亞",
        "武統 言論自由",
        "民進黨 獨裁"
    ]
    
    # Setup Google Search API
    service, search_engine_id = setup_google_search()
    if not service or not search_engine_id:
        print("Failed to setup Google Search API. Please check your API key and search engine ID.")
        return
    
    # Create a list to store all results
    all_results = []
    
    # Search for each keyword
    for keyword in keywords:
        print(f"Searching for: {keyword}")
        results = search_keyword(service, search_engine_id, keyword)
        all_results.extend(results)
        print(f"Found {len(results)} results for {keyword}")
        
        # Sleep between keywords to avoid rate limiting
        time.sleep(2)
    
    # Convert results to DataFrame and save to CSV
    df = pd.DataFrame(all_results)
    df.to_csv('all.csv', index=False, encoding='utf-8-sig')
    print(f"Saved {len(all_results)} total results to all.csv")

if __name__ == "__main__":
    main() 