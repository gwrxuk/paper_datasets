import os
import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import jieba
from wordcloud import WordCloud
import matplotlib.font_manager as fm
import re
from snownlp import SnowNLP
from jinja2 import Template

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Configure matplotlib font settings
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']  # macOS Chinese font
plt.rcParams['axes.unicode_minus'] = False

def remove_numbers(text):
    """Remove numbers from text."""
    return re.sub(r'\d+', '', text)

def load_segmented_files(folder_path):
    """Load all segmented files from the specified folder."""
    logging.info("Loading segmented files...")
    files = []
    for filename in os.listdir(folder_path):
        if filename.endswith('_segmented.txt'):
            with open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:  # Only include non-empty files
                    # Remove numbers from content
                    content = remove_numbers(content)
                    files.append(content)
    return files

def analyze_word_distribution(texts):
    """Analyze word distribution and create visualization."""
    logging.info("Analyzing word distribution...")
    
    # Combine all texts and split into words
    all_words = []
    for text in texts:
        words = text.split()
        all_words.extend(words)
    
    # Count word frequencies
    word_counts = pd.Series(all_words).value_counts()
    
    # Filter for words with more than one character
    multi_char_words = word_counts[word_counts.index.str.len() > 1]
    
    logging.info(f"Total unique words: {len(word_counts)}")
    logging.info(f"Top 20 most frequent multi-character words:")
    for word, count in multi_char_words.head(20).items():
        logging.info(f"{word}: {count}")
    
    # Create word distribution visualization
    logging.info("Creating word distribution visualization...")
    plt.figure(figsize=(12, 6))
    multi_char_words.head(20).plot(kind='bar')
    plt.title('Top 20 Most Frequent Multi-Character Words')
    plt.xlabel('Words')
    plt.ylabel('Frequency')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('word_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_word_cloud(word_counts):
    """Create a word cloud visualization."""
    logging.info("Creating word cloud...")
    
    # Get Chinese font
    font_path = '/System/Library/Fonts/Supplemental/Arial Unicode.ttf'  # macOS Chinese font
    
    # Create word cloud
    wordcloud = WordCloud(
        font_path=font_path,
        width=800,
        height=400,
        background_color='white',
        max_words=100
    ).generate_from_frequencies(dict(word_counts))
    
    # Plot word cloud
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.tight_layout()
    plt.savefig('word_cloud.png', dpi=300, bbox_inches='tight')
    plt.close()

def perform_topic_modeling(texts, n_topics=5):
    """Perform topic modeling using LDA."""
    logging.info("Performing topic modeling...")
    
    # Create document-term matrix
    vectorizer = CountVectorizer(max_features=1000)
    dtm = vectorizer.fit_transform(texts)
    
    # Fit LDA model
    lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda.fit(dtm)
    
    # Get feature names
    feature_names = vectorizer.get_feature_names_out()
    
    # Print topics
    logging.info(f"Top {n_topics} topics:")
    for topic_idx, topic in enumerate(lda.components_):
        top_words_idx = topic.argsort()[:-10 - 1:-1]
        top_words = [feature_names[i] for i in top_words_idx]
        logging.info(f"Topic {topic_idx + 1}: {' '.join(top_words)}")

    return [top_words for top_words in [top_words for topic in lda.components_ for top_words in [feature_names[i] for i in topic.argsort()[:-10 - 1:-1]]]]

def analyze_sentiment(texts):
    """Analyze sentiment of texts using SnowNLP."""
    logging.info("Analyzing sentiment...")
    
    sentiments = []
    for text in texts:
        s = SnowNLP(text)
        sentiments.append(s.sentiments)
    
    # Convert to numpy array for easier analysis
    sentiments = np.array(sentiments)
    
    # Calculate statistics
    mean_sentiment = np.mean(sentiments)
    median_sentiment = np.median(sentiments)
    std_sentiment = np.std(sentiments)
    
    logging.info(f"Mean sentiment: {mean_sentiment:.3f}")
    logging.info(f"Median sentiment: {median_sentiment:.3f}")
    logging.info(f"Standard deviation: {std_sentiment:.3f}")
    
    # Create sentiment distribution visualization
    plt.figure(figsize=(10, 6))
    sns.histplot(sentiments, bins=20, kde=True)
    plt.title('Sentiment Distribution')
    plt.xlabel('Sentiment Score (0-1)')
    plt.ylabel('Frequency')
    plt.axvline(mean_sentiment, color='r', linestyle='--', label=f'Mean: {mean_sentiment:.3f}')
    plt.legend()
    plt.tight_layout()
    plt.savefig('sentiment_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    return {
        'mean': mean_sentiment,
        'median': median_sentiment,
        'std': std_sentiment,
        'distribution': sentiments
    }

def analyze_word_sentiment(texts, top_words):
    """Analyze sentiment of individual words."""
    logging.info("Analyzing word sentiment...")
    
    word_sentiments = {}
    for word in top_words:
        # Create sample sentences with the word
        sample_sentences = [f"這個{word}很好", f"這個{word}很壞"]
        sentiments = []
        for sentence in sample_sentences:
            s = SnowNLP(sentence)
            sentiments.append(s.sentiments)
        
        # Calculate average sentiment
        avg_sentiment = np.mean(sentiments)
        word_sentiments[word] = {
            'sentiment': avg_sentiment,
            'category': 'positive' if avg_sentiment > 0.6 else 'negative' if avg_sentiment < 0.4 else 'neutral'
        }
    
    return word_sentiments

def generate_html_report(texts, stats, word_distribution, topics, sentiment_results, word_sentiments):
    """Generate HTML report with all analysis results."""
    logging.info("Generating HTML report...")
    
    # HTML template
    html_template = """
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>文本分析結果（不含數字）</title>
        <style>
            body {
                font-family: 'Arial Unicode MS', Arial, sans-serif;
                line-height: 1.6;
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            h1, h2 {
                color: #333;
                border-bottom: 2px solid #eee;
                padding-bottom: 10px;
            }
            .stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .stat-card {
                background-color: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                text-align: center;
            }
            .stat-number {
                font-size: 24px;
                font-weight: bold;
                color: #007bff;
            }
            .word-list {
                list-style: none;
                padding: 0;
            }
            .word-item {
                display: flex;
                justify-content: space-between;
                padding: 8px;
                border-bottom: 1px solid #eee;
            }
            .word-item:hover {
                background-color: #f8f9fa;
            }
            .topic {
                background-color: #e9ecef;
                padding: 15px;
                margin: 10px 0;
                border-radius: 5px;
            }
            .images {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .image-container {
                text-align: center;
            }
            img {
                max-width: 100%;
                height: auto;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .note {
                background-color: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 20px 0;
                border-radius: 0 5px 5px 0;
            }
            .sentiment-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 20px;
            }
            .sentiment-box {
                background-color: white;
                padding: 15px;
                border-radius: 5px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                text-align: center;
            }
            .sentiment-value {
                font-size: 24px;
                font-weight: bold;
                color: #3498db;
            }
            .word-sentiment {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 10px;
                margin: 20px 0;
            }
            .sentiment-category {
                padding: 10px;
                border-radius: 5px;
                margin-bottom: 10px;
            }
            .positive {
                background-color: #d4edda;
                color: #155724;
            }
            .negative {
                background-color: #f8d7da;
                color: #721c24;
            }
            .neutral {
                background-color: #e2e3e5;
                color: #383d41;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>文本分析結果（不含數字）</h1>
            
            <div class="note">
                <strong>注意：</strong>本分析已移除所有數字，以便更好地理解文本中的詞彙分布。
            </div>

            <h2>數據統計</h2>
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number">{{ stats.total_files }}</div>
                    <div>文件總數</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ stats.total_words }}</div>
                    <div>總字數</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ stats.avg_words }}</div>
                    <div>平均每篇字數</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ stats.unique_words }}</div>
                    <div>獨特詞彙數</div>
                </div>
            </div>

            <h2>高頻詞彙（前20名）</h2>
            <ul class="word-list">
                {% for word, count in word_distribution %}
                <li class="word-item"><span>{{ word }}</span><span>{{ count }}次</span></li>
                {% endfor %}
            </ul>

            <h2>情感分析</h2>
            <div class="sentiment-stats">
                <div class="sentiment-box">
                    <h3>平均情感分數</h3>
                    <div class="sentiment-value">{{ sentiment_results.mean|round(3) }}</div>
                    <p>（0-1範圍，越高越正面）</p>
                </div>
                <div class="sentiment-box">
                    <h3>中位數情感分數</h3>
                    <div class="sentiment-value">{{ sentiment_results.median|round(3) }}</div>
                </div>
                <div class="sentiment-box">
                    <h3>標準差</h3>
                    <div class="sentiment-value">{{ sentiment_results.std|round(3) }}</div>
                </div>
            </div>

            <h2>詞彙情感分類</h2>
            <div class="word-sentiment">
                <div>
                    <h3>正面詞彙</h3>
                    {% for word, data in word_sentiments.items() %}
                    {% if data.category == 'positive' %}
                    <div class="sentiment-category positive">{{ word }} ({{ data.sentiment|round(3) }})</div>
                    {% endif %}
                    {% endfor %}
                </div>
                <div>
                    <h3>負面詞彙</h3>
                    {% for word, data in word_sentiments.items() %}
                    {% if data.category == 'negative' %}
                    <div class="sentiment-category negative">{{ word }} ({{ data.sentiment|round(3) }})</div>
                    {% endif %}
                    {% endfor %}
                </div>
                <div>
                    <h3>中性詞彙</h3>
                    {% for word, data in word_sentiments.items() %}
                    {% if data.category == 'neutral' %}
                    <div class="sentiment-category neutral">{{ word }} ({{ data.sentiment|round(3) }})</div>
                    {% endif %}
                    {% endfor %}
                </div>
            </div>

            <h2>主題分析</h2>
            {% for topic in topics %}
            <div class="topic">
                <h3>主題 {{ loop.index }}：{{ topic.title }}</h3>
                <p>{{ topic.words }}</p>
            </div>
            {% endfor %}

            <h2>視覺化</h2>
            <div class="images">
                <div class="image-container">
                    <h3>詞頻分布</h3>
                    <img src="word_distribution.png" alt="詞頻分布圖">
                </div>
                <div class="image-container">
                    <h3>文字雲</h3>
                    <img src="word_cloud.png" alt="文字雲">
                </div>
                <div class="image-container">
                    <h3>情感分布</h3>
                    <img src="sentiment_distribution.png" alt="情感分布圖">
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Prepare data for template
    template_data = {
        'stats': stats,
        'word_distribution': word_distribution,
        'topics': [{'title': f'主題 {i+1}', 'words': ' '.join(words)} for i, words in enumerate(topics)],
        'sentiment_results': sentiment_results,
        'word_sentiments': word_sentiments
    }
    
    # Render template
    template = Template(html_template)
    html_content = template.render(**template_data)
    
    # Save HTML file
    with open('analysis_results.html', 'w', encoding='utf-8') as f:
        f.write(html_content)

def main():
    # Get current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    segment_folder = os.path.join(current_dir, "segment")
    
    # Load segmented files
    texts = load_segmented_files(segment_folder)
    
    # Print dataset statistics
    logging.info(f"Total number of files: {len(texts)}")
    total_words = sum(len(text.split()) for text in texts)
    logging.info(f"Total number of words: {total_words}")
    logging.info(f"Average words per file: {total_words/len(texts):.2f}")
    
    # Analyze word distribution
    all_words = []
    for text in texts:
        words = text.split()
        all_words.extend(words)
    word_counts = pd.Series(all_words).value_counts()
    multi_char_words = word_counts[word_counts.index.str.len() > 1]
    
    # Get top 20 words
    top_words = multi_char_words.head(20).index.tolist()
    
    # Analyze word sentiment
    word_sentiments = analyze_word_sentiment(texts, top_words)
    
    # Perform sentiment analysis
    sentiment_results = analyze_sentiment(texts)
    
    # Create visualizations
    analyze_word_distribution(texts)
    create_word_cloud(multi_char_words)
    
    # Perform topic modeling
    topics = perform_topic_modeling(texts)
    
    # Generate HTML report
    generate_html_report(
        texts=texts,
        stats={
            'total_files': len(texts),
            'total_words': total_words,
            'avg_words': total_words/len(texts),
            'unique_words': len(word_counts)
        },
        word_distribution=list(zip(top_words, multi_char_words.head(20).values)),
        topics=topics,
        sentiment_results=sentiment_results,
        word_sentiments=word_sentiments
    )

if __name__ == "__main__":
    main() 