import os
import pandas as pd
from collections import Counter
import jieba
import re
from bs4 import BeautifulSoup
import logging
import matplotlib.pyplot as plt
import base64
from io import BytesIO
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import numpy as np
from snownlp import SnowNLP
import seaborn as sns
import matplotlib.font_manager as fm

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Set up Chinese font
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# Custom words for jieba
custom_words = [
    "反綠共", "綠共", "中國國民黨", "民進黨", "民主進步黨",
    "雙標", "亞亞", "中配", "陸配", "言論自由"
]

def get_text_content(segment_dir):
    """Get text content from segmented files."""
    all_texts = []
    for filename in os.listdir(segment_dir):
        if filename.endswith('_segmented.txt'):
            try:
                with open(os.path.join(segment_dir, filename), 'r', encoding='utf-8') as f:
                    text = ' '.join(f.read().splitlines())
                    all_texts.append(text)
            except Exception as e:
                logger.error(f"Error reading {filename}: {str(e)}")
    return all_texts

def get_word_frequencies(texts):
    """Get word frequencies from texts."""
    all_words = []
    for text in texts:
        words = text.split()
        all_words.extend(words)
    
    # Filter out non-Chinese characters, numbers, English words, and short words
    chinese_pattern = re.compile(r'[\u4e00-\u9fff]+')
    filtered_words = [
        word for word in all_words 
        if chinese_pattern.match(word) 
        and len(word) > 1 
        and not any(c.isdigit() for c in word)  # Filter out words containing numbers
        and not any(c.isascii() for c in word)  # Filter out words containing English characters
    ]
    
    # Count word frequencies
    word_counts = Counter(filtered_words)
    return word_counts

def calculate_tfidf(texts):
    """Calculate TF-IDF scores."""
    # Preprocess texts to remove numbers and English words
    processed_texts = []
    for text in texts:
        # Remove any words containing numbers or English characters
        words = text.split()
        filtered_words = [
            word for word in words 
            if not any(c.isdigit() for c in word) 
            and not any(c.isascii() for c in word)
        ]
        processed_texts.append(' '.join(filtered_words))
    
    vectorizer = TfidfVectorizer(max_features=1000)
    tfidf_matrix = vectorizer.fit_transform(processed_texts)
    feature_names = vectorizer.get_feature_names_out()
    
    # Get average TF-IDF scores for each term
    avg_tfidf = np.array(tfidf_matrix.mean(axis=0)).flatten()
    tfidf_scores = list(zip(feature_names, avg_tfidf))
    tfidf_scores.sort(key=lambda x: x[1], reverse=True)
    
    return tfidf_scores[:50]  # Return top 50 terms

def perform_topic_modeling(texts, n_topics=5):
    """Perform topic modeling using LDA."""
    vectorizer = TfidfVectorizer(max_features=1000)
    doc_term_matrix = vectorizer.fit_transform(texts)
    feature_names = vectorizer.get_feature_names_out()
    
    lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda.fit(doc_term_matrix)
    
    topics = []
    for topic_idx, topic in enumerate(lda.components_):
        top_terms = [feature_names[i] for i in topic.argsort()[:-10:-1]]
        topics.append((f"Topic {topic_idx + 1}", top_terms))
    
    return topics

def analyze_sentiment(texts):
    """Analyze sentiment using SnowNLP."""
    sentiments = []
    for text in texts:
        try:
            sentiment = SnowNLP(text).sentiments
            sentiments.append(sentiment)
        except:
            continue
    
    return {
        'average': np.mean(sentiments),
        'std': np.std(sentiments),
        'distribution': np.histogram(sentiments, bins=5)[0].tolist()
    }

def generate_word_distribution_plot(word_freq):
    """Generate word frequency distribution plot"""
    plt.figure(figsize=(12, 6))
    words = list(word_freq.keys())[:30]
    freqs = list(word_freq.values())[:30]
    
    sns.barplot(x=freqs, y=words)
    plt.title('Top 30 Words Distribution')
    plt.xlabel('Frequency')
    plt.ylabel('Words')
    plt.tight_layout()
    
    # Save plot to bytes buffer
    buf = BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    plt.close()
    
    # Encode the image to base64
    buf.seek(0)
    img_base64 = base64.b64encode(buf.getvalue()).decode()
    return img_base64

def generate_html_report(texts, word_counts, tfidf_scores, topics, sentiment_results, distribution_base64):
    """Generate HTML report with analysis results."""
    total_words = sum(word_counts.values())
    unique_words = len(word_counts)
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Text Mining Results</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .section {{ margin-bottom: 30px; }}
            table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; }}
            th, td {{ padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background-color: #f2f2f2; }}
            .stats {{ margin: 20px 0; }}
            .chart {{ text-align: center; margin: 20px 0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Text Mining Analysis Results</h1>
            
            <div class="section">
                <h2>Dataset Statistics</h2>
                <div class="stats">
                    <p>Total documents analyzed: {len(texts)}</p>
                    <p>Total words: {total_words}</p>
                    <p>Unique words: {unique_words}</p>
                    <p>Average words per document: {total_words/len(texts):.2f}</p>
                </div>
            </div>

            <div class="section">
                <h2>Word Distribution</h2>
                <div class="chart">
                    <img src="data:image/png;base64,{distribution_base64}" alt="Word Distribution">
                </div>
            </div>
            
            <div class="section">
                <h2>Top TF-IDF Terms</h2>
                <table>
                    <tr>
                        <th>Term</th>
                        <th>TF-IDF Score</th>
                    </tr>
    """
    
    for term, score in tfidf_scores:
        html_content += f"""
                    <tr>
                        <td>{term}</td>
                        <td>{score:.4f}</td>
                    </tr>
        """
    
    html_content += """
                </table>
            </div>
            
            <div class="section">
                <h2>Topic Analysis</h2>
                <table>
                    <tr>
                        <th>Topic</th>
                        <th>Top Terms</th>
                    </tr>
    """
    
    for topic_name, terms in topics:
        html_content += f"""
                    <tr>
                        <td>{topic_name}</td>
                        <td>{', '.join(terms)}</td>
                    </tr>
        """
    
    html_content += f"""
                </table>
            </div>
            
            <div class="section">
                <h2>Sentiment Analysis</h2>
                <div class="stats">
                    <p>Average sentiment score: {sentiment_results['average']:.3f} (0 = negative, 1 = positive)</p>
                    <p>Standard deviation: {sentiment_results['std']:.3f}</p>
                    <p>Sentiment distribution (0-0.2, 0.2-0.4, 0.4-0.6, 0.6-0.8, 0.8-1.0):</p>
                    <p>{sentiment_results['distribution']}</p>
                </div>
            </div>
            
            <div class="section">
                <h2>Most Frequent Words</h2>
                <table>
                    <tr>
                        <th>Rank</th>
                        <th>Word</th>
                        <th>Frequency</th>
                        <th>Percentage</th>
                    </tr>
    """
    
    for rank, (word, count) in enumerate(word_counts.most_common(50), 1):
        percentage = (count / total_words) * 100
        html_content += f"""
                    <tr>
                        <td>{rank}</td>
                        <td>{word}</td>
                        <td>{count}</td>
                        <td>{percentage:.2f}%</td>
                    </tr>
        """
    
    html_content += """
                </table>
            </div>
        </div>
    </body>
    </html>
    """
    
    with open('result.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    logger.info("HTML report generated successfully")

def main():
    # Get text content
    logger.info("Reading text content...")
    texts = get_text_content('segment')
    
    # Get word frequencies
    logger.info("Analyzing word frequencies...")
    word_counts = get_word_frequencies(texts)
    
    # Calculate TF-IDF
    logger.info("Calculating TF-IDF scores...")
    tfidf_scores = calculate_tfidf(texts)
    
    # Perform topic modeling
    logger.info("Performing topic modeling...")
    topics = perform_topic_modeling(texts)
    
    # Analyze sentiment
    logger.info("Analyzing sentiment...")
    sentiment_results = analyze_sentiment(texts)
    
    # Generate word distribution plot
    logger.info("Generating word distribution plot...")
    distribution_base64 = generate_word_distribution_plot(word_counts)
    
    # Generate HTML report
    logger.info("Generating HTML report...")
    generate_html_report(texts, word_counts, tfidf_scores, topics, sentiment_results, distribution_base64)

if __name__ == "__main__":
    main() 