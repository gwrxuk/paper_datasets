import os
import time
import random
import pandas as pd
import requests
from bs4 import BeautifulSoup
import jieba
import re
from urllib.parse import urlparse
import logging
from fake_useragent import UserAgent
import uuid

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create directories if they don't exist
os.makedirs('fetched', exist_ok=True)
os.makedirs('segment', exist_ok=True)

# Initialize UserAgent
ua = UserAgent()

def fetch_content(url):
    """Fetch content from URL with proper headers and error handling."""
    headers = {
        'User-Agent': ua.random,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code != 200:
            logger.error(f"Error fetching {url}: HTTP {response.status_code}")
            return None
            
        # Check if content is HTML
        if 'text/html' in response.headers.get('Content-Type', ''):
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Get text content
            text = soup.get_text()
            
            # Clean up text
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            # Check if text contains Chinese characters
            if not any('\u4e00' <= char <= '\u9fff' for char in text):
                logger.info(f"No Chinese content found in {url}")
                return None
                
            return text
        else:
            # For non-HTML content, check if it contains Chinese
            if not any('\u4e00' <= char <= '\u9fff' for char in response.text):
                logger.info(f"No Chinese content found in {url}")
                return None
            return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching {url}: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error fetching {url}: {str(e)}")
        return None

def segment_text(text):
    """Segment Chinese text using jieba."""
    if not text:
        return []
    
    # Add custom words to jieba dictionary
    custom_words = [
        "反綠共", "綠共", "中國國民黨", "民進黨", "民主進步黨",
        "雙標", "亞亞", "中配", "陸配", "言論自由"
    ]
    for word in custom_words:
        jieba.add_word(word)
    
    # Segment text
    words = jieba.cut(text, cut_all=False)
    return list(words)

def process_urls():
    """Process all URLs from all.csv"""
    df = pd.read_csv('all.csv')
    urls = df['link'].tolist()
    
    for i, url in enumerate(urls, 1):
        try:
            logger.info(f"Processing URL {i}/{len(urls)}: {url}")
            
            # Generate a unique filename for this URL
            filename = str(uuid.uuid4())
            
            # Check if we've already processed this URL
            if os.path.exists(f'segment/{filename}_segmented.txt'):
                logger.info(f"Skipping already processed file: {filename}")
                continue
            
            # Fetch content
            content = fetch_content(url)
            if content:
                # Save fetched content
                with open(f'fetched/{filename}.txt', 'w', encoding='utf-8') as f:
                    f.write(content)
                logger.info(f"Saved fetched content to fetched/{filename}.txt")
                
                # Segment content
                segmented_content = segment_text(content)
                if segmented_content:
                    # Save segmented content
                    with open(f'segment/{filename}_segmented.txt', 'w', encoding='utf-8') as f:
                        f.write('\n'.join(segmented_content))
                    logger.info(f"Saved segmented content to segment/{filename}_segmented.txt")
            
            # Add a longer delay between requests (3-5 seconds)
            time.sleep(random.uniform(3, 5))
            
        except Exception as e:
            logger.error(f"Error processing URL {url}: {str(e)}")
            continue

if __name__ == "__main__":
    process_urls() 